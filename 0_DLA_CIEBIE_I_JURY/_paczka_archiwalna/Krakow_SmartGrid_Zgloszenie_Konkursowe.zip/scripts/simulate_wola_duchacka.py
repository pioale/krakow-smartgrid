"""
Kraków SmartGrid: Dedykowana Symulacja i Studium Przypadku dla Zajezdni MPK Wola Duchacka
Główny punkt ciężkości zgłoszenia konkursowego „Open Data App” (UMK Kraków 2026).

Profil infrastruktury:
- 52 stacje ładowania autobusów elektrycznych (CCS Combo 2 i szybkie ładowarki pantografowe).
- Moc przyłączeniowa do sieci Tauron Dystrybucja: 5,2 MW (Taryfa B23).
- Flota: 85 autobusów elektrycznych Solaris Urbino 12 / 18 Electric.
- Wieczorny szczyt zjazdowy (21:00 - 23:30): niezarządzane zapotrzebowanie sięgające 4,8 MW.
- Rozwiązanie: Kontenerowy Magazyn Energii BESS 2,0 MW / 4,0 MWh (technologia LFP, Behind-the-Meter).
- Efekt: Ścięcie szczytu do 3,2 MW (redukcja o 1,6 MW), roczne oszczędności 750k - 820k PLN.
"""

import os
import json
import numpy as np
import pandas as pd
from data_loader import KrakowDataLoader
from grid_optimizer import KrakowGridOptimizer
from bess_degradation import KrakowBessDegradationModel


def run_wola_duchacka_case_study(output_dir: str = None) -> dict:
    if output_dir is None:
        output_dir = os.path.join(os.path.dirname(__file__), "data")
    os.makedirs(output_dir, exist_ok=True)

    print("=" * 80)
    print("KRAKÓW SMARTGRID: SYMULACJA NAJWYŻSZEJ PRECYZJI DLA ZAJEZDNI WOLA DUCHACKA")
    print("=" * 80)

    # 1. Pobranie i przygotowanie 7-dniowego profilu 15-minutowego (672 próbki)
    loader = KrakowDataLoader()
    df_raw = loader.generate_synthetic_hourly_profile("DEP-01", days=7)
    
    # Precyzyjne dopasowanie parametrów zajezdni Wola Duchacka
    bess_capacity_mwh = 4.0   # 4 MWh pojemności użytkowej
    bess_power_mw = 2.0       # 2 MW mocy falownika PCS
    target_peak_mw = 3.2      # Cel redukcji szczytu z 4.8 MW do 3.2 MW
    contracted_power_mw = 5.2 # Moc przyłącza
    tariff_b23_contracted_rate = 21.50 # PLN/kW/miesiąc składnik stały Tauron B23
    capacity_fee_rate = 141.20 # PLN/MWh opłata mocowa URE 2026

    optimizer = KrakowGridOptimizer(
        bess_capacity_mwh=bess_capacity_mwh,
        bess_power_mw=bess_power_mw,
        rte=0.88,
        capacity_fee_rate_pln_mwh=capacity_fee_rate,
        contracted_power_rate_pln_kw_month=tariff_b23_contracted_rate,
        behind_the_meter=True
    )

    # 2. Wykonanie globalnej optymalizacji MILP (HiGHS)
    print("\n[1/4] Rozwiązywanie problemu programowania liniowego MILP (SciPy HiGHS)...")
    df_opt = optimizer.optimize_city_grid_milp(df_raw, target_peak_mw=target_peak_mw)

    # 3. Szczegółowe kalkulacje ekonomiczne taryfy B23
    print("[2/4] Wyliczanie składowych rachunku Tauron B23 i opłaty mocowej URE...")
    savings = optimizer.calculate_city_savings(
        df_opt,
        capex_pln_per_mwh=950000.0,
        subsidy_ratio=0.70,
        bess_reliability_factor=0.98
    )

    # 4. Model starzenia elektrochemicznego LFP
    print("[3/4] Symulacja trajektorii starzenia LFP (15 lat, degradacja kalendarzowa i cykliczna)...")
    deg_model = KrakowBessDegradationModel("LFP")
    deg_results = deg_model.simulate_degradation_trajectory(
        capacity_mwh=bess_capacity_mwh,
        cycles_per_day=1.1,
        avg_dod=0.75,
        avg_cell_temp_c=20.0,
        years=15
    )

    # 5. Przygotowanie syntetycznego zestawienia wskaźników
    raw_peak = float(df_opt["Grid_Demand_MW"].max())
    opt_peak = float(df_opt["Net_Grid_Demand_MW"].max())
    peak_reduction = raw_peak - opt_peak

    kpi = {
        "Hub_ID": "DEP-01",
        "Hub_Name": "Zajezdnia Autobusowa MPK Kraków – Wola Duchacka",
        "EV_Buses_Count": 85,
        "EV_Chargers_Count": 52,
        "Grid_Connection_Capacity_MW": contracted_power_mw,
        "Unmanaged_Peak_Load_MW": round(raw_peak, 2),
        "Managed_Peak_Load_MW": round(opt_peak, 2),
        "Peak_Shaved_MW": round(peak_reduction, 2),
        "Peak_Reduction_Percent": round((peak_reduction / raw_peak) * 100.0, 1),
        "BESS_Technology": "Litowo-Żelazowo-Fosforanowe (LiFePO4 / LFP)",
        "BESS_Capacity_MWh": bess_capacity_mwh,
        "BESS_Power_MW": bess_power_mw,
        "BESS_Round_Trip_Efficiency": 0.88,
        "Tariff_Type": "Tauron Dystrybucja B23 (Behind-the-Meter)",
        "Contracted_Power_Rate_PLN_kW_Month": tariff_b23_contracted_rate,
        "Monthly_Contracted_Power_Savings_PLN": savings["Monthly_Contracted_Power_Savings_PLN"],
        "Annual_Contracted_Power_Savings_PLN": savings["Contracted_Power_Savings_PLN_Year"],
        "Annual_Capacity_Fee_Savings_PLN": savings["Capacity_Fee_Savings_PLN_Year"],
        "Annual_Tariff_Arbitrage_Savings_PLN": savings["Tariff_Arbitrage_Savings_PLN_Year"],
        "Total_Annual_Savings_PLN": savings["Total_Annual_Savings_PLN"],
        "Total_CAPEX_PLN": savings["Total_CAPEX_PLN"],
        "EU_Subsidy_Ratio_Percent": 70.0,
        "Municipal_Equity_PLN": savings["Municipal_Equity_PLN"],
        "Simple_Payback_Gross_Years": savings["Simple_Payback_Years"],
        "Simple_Payback_Subsidized_Years": savings["Subsidized_Payback_Years"],
        "BESS_SoH_After_10_Years_Percent": deg_results["SoH_After_10_Years_Percent"],
        "BESS_SoH_After_15_Years_Percent": deg_results["SoH_After_15_Years_Percent"],
        "BESS_EOL_Horizon": deg_results["EOL_Year_80_Percent"],
        "LCOS_PLN_MWh": deg_results["Estimated_LCOS_PLN_MWh"],
        "Regulatory_Model": "Behind-the-Meter (BtM) - brak wymogu koncesji na magazyn do 10 MW na potrzeby własne",
        "Wholesale_Market_Roadmap": "Opcja rozwojowa od 2027 r. w formule DSR / DUB po certyfikacji JGM"
    }

    # 6. Zapis plików danych (CSV i JSON)
    csv_path = os.path.join(output_dir, "wola_duchacka_simulation_timeseries.csv")
    json_path = os.path.join(output_dir, "wola_duchacka_kpi_summary.json")

    # Dodatkowe kolumny analityczne do CSV
    df_export = df_opt[[
        "Datetime", "Grid_Demand_MW", "Net_Grid_Demand_MW",
        "BESS_Charge_MW", "BESS_Discharge_MW", "BESS_SoC_MWh",
        "Peak_Reduced_MW", "Tariff_PLN_MWh"
    ]].copy()
    df_export.rename(columns={
        "Grid_Demand_MW": "Pobor_Niezarzadzany_MW",
        "Net_Grid_Demand_MW": "Pobor_Zoptymalizowany_Siec_MW",
        "BESS_Charge_MW": "Moc_Ladowania_BESS_MW",
        "BESS_Discharge_MW": "Moc_Rozladowania_BESS_MW",
        "BESS_SoC_MWh": "Stan_Energii_BESS_MWh",
        "Peak_Reduced_MW": "Moc_Scieta_MW",
        "Tariff_PLN_MWh": "Taryfa_B23_PLN_MWh"
    }, inplace=True)
    df_export.to_csv(csv_path, index=False, float_format="%.3f")

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(kpi, f, indent=2, ensure_ascii=False)

    print(f"\n[4/4] Pliki pomyślnie zapisane:")
    print(f"  -> Szereg czasowy (CSV): {csv_path}")
    print(f"  -> Raport wskaźników (JSON): {json_path}")

    # 7. Wygenerowanie interaktywnego raportu HTML z wykresami SVG
    html_path = os.path.join(os.path.dirname(__file__), "wola_duchacka_case_study.html")
    generate_html_case_study(df_export.head(96), kpi, deg_results["Trajectory_DataFrame"], html_path)
    print(f"  -> Interaktywny raport HTML: {html_path}")

    print("\n" + "=" * 80)
    print("PODSUMOWANIE WSKAŹNIKÓW DLA MPK WOLA DUCHACKA:")
    print(f"  Szczyt pierwotny:       {kpi['Unmanaged_Peak_Load_MW']} MW")
    print(f"  Szczyt po BESS:          {kpi['Managed_Peak_Load_MW']} MW  (ścięcie o {kpi['Peak_Shaved_MW']} MW / {kpi['Peak_Reduction_Percent']}%)")
    print(f"  Oszczędność mocy zam.:   {kpi['Annual_Contracted_Power_Savings_PLN']:,.0f} PLN/rok")
    print(f"  Oszczędność opł. mocowej:{kpi['Annual_Capacity_Fee_Savings_PLN']:,.0f} PLN/rok")
    print(f"  Arbitraż strefowy B23:   {kpi['Annual_Tariff_Arbitrage_Savings_PLN']:,.0f} PLN/rok")
    print(f"  ŁĄCZNA OSZCZĘDNOŚĆ:      {kpi['Total_Annual_Savings_PLN']:,.0f} PLN/ROK")
    print(f"  Nakłady (Wkład Miasta): {kpi['Municipal_Equity_PLN']:,.0f} PLN (po 70% dotacji FEnIKS)")
    print(f"  Zwrot z inwestycji:      {kpi['Simple_Payback_Subsidized_Years']} roku")
    print(f"  Trwałość BESS (SoH 15Y): {kpi['BESS_SoH_After_15_Years_Percent']}% (LFP EOL: {kpi['BESS_EOL_Horizon']})")
    print("=" * 80)

    return kpi


def generate_html_case_study(df_24h: pd.DataFrame, kpi: dict, df_deg: pd.DataFrame, output_html: str):
    """Generuje interaktywny, elegancki raport techniczno-ekonomiczny w HTML z wbudowanymi wykresami SVG."""
    
    # Przygotowanie punktów do wykresu SVG dla profilu 24h
    w = 800
    h = 240
    pad_l = 50
    pad_r = 20
    pad_t = 20
    pad_b = 30
    plot_w = w - pad_l - pad_r
    plot_h = h - pad_t - pad_b

    p_raw = df_24h["Pobor_Niezarzadzany_MW"].values
    p_opt = df_24h["Pobor_Zoptymalizowany_Siec_MW"].values
    soc = df_24h["Stan_Energii_BESS_MWh"].values
    n = len(df_24h)

    max_p = max(5.5, max(p_raw.max(), p_opt.max()) * 1.1)

    def to_coords_p(val_arr):
        pts = []
        for i, v in enumerate(val_arr):
            x = pad_l + (i / (n - 1)) * plot_w
            y = pad_t + plot_h - (v / max_p) * plot_h
            pts.append(f"{x:.1f},{y:.1f}")
        return " ".join(pts)

    def to_coords_soc(val_arr):
        pts = []
        for i, v in enumerate(val_arr):
            x = pad_l + (i / (n - 1)) * plot_w
            y = pad_t + plot_h - (v / 4.0) * plot_h
            pts.append(f"{x:.1f},{y:.1f}")
        return " ".join(pts)

    raw_line = to_coords_p(p_raw)
    opt_line = to_coords_p(p_opt)
    soc_line = to_coords_soc(soc)

    # Siatka godzinowa
    grid_lines = []
    for hr in range(0, 25, 4):
        idx = min(n - 1, int((hr / 24.0) * n))
        x = pad_l + (idx / (n - 1)) * plot_w
        grid_lines.append(f'<line x1="{x:.1f}" y1="{pad_t}" x2="{x:.1f}" y2="{pad_t + plot_h}" stroke="#334155" stroke-dasharray="3,3" />')
        grid_lines.append(f'<text x="{x:.1f}" y="{pad_t + plot_h + 18}" fill="#94a3b8" font-size="11" text-anchor="middle">{hr:02d}:00</text>')

    # Oś Y dla MW
    y_labels = []
    for mw in range(0, 6):
        y = pad_t + plot_h - (mw / max_p) * plot_h
        grid_lines.append(f'<line x1="{pad_l}" y1="{y:.1f}" x2="{pad_l + plot_w}" y2="{y:.1f}" stroke="#1e293b" />')
        y_labels.append(f'<text x="{pad_l - 8}" y="{y + 4:.1f}" fill="#94a3b8" font-size="11" text-anchor="end">{mw} MW</text>')

    html_content = f"""<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Studium Przypadku: MPK Kraków Wola Duchacka | Kraków SmartGrid</title>
  <style>
    :root {{
      --bg: #0b0f19;
      --card-bg: #151d2e;
      --border: #23324d;
      --accent: #10b981;
      --danger: #ef4444;
      --warning: #f59e0b;
      --text: #f8fafc;
      --muted: #94a3b8;
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }}
    body {{ background: var(--bg); color: var(--text); padding: 32px 20px; line-height: 1.5; }}
    .container {{ max-width: 1040px; margin: 0 auto; }}
    .header {{ border-bottom: 1px solid var(--border); padding-bottom: 24px; margin-bottom: 28px; }}
    .badge {{ display: inline-block; padding: 4px 10px; font-size: 11px; font-weight: 700; text-transform: uppercase; border-radius: 4px; background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3); margin-bottom: 10px; }}
    h1 {{ font-size: 26px; font-weight: 800; color: #fff; margin-bottom: 8px; }}
    .subtitle {{ color: var(--muted); font-size: 14px; max-width: 800px; }}
    
    .grid-kpi {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 28px; }}
    .card {{ background: var(--card-bg); border: 1px solid var(--border); border-radius: 10px; padding: 18px; }}
    .card-title {{ font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--muted); margin-bottom: 6px; }}
    .card-value {{ font-size: 26px; font-weight: 800; color: #fff; }}
    .card-diff {{ font-size: 12px; margin-top: 4px; }}
    .diff-pos {{ color: #10b981; }}
    .diff-neg {{ color: #ef4444; }}

    .chart-section {{ background: var(--card-bg); border: 1px solid var(--border); border-radius: 10px; padding: 22px; margin-bottom: 28px; }}
    .chart-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; flex-wrap: wrap; gap: 10px; }}
    .legend {{ display: flex; gap: 16px; font-size: 12px; font-weight: 600; }}
    .legend-item {{ display: flex; align-items: center; gap: 6px; }}
    .dot {{ width: 10px; height: 10px; border-radius: 50%; }}

    .financial-table {{ width: 100%; border-collapse: collapse; margin-top: 14px; font-size: 13px; }}
    .financial-table th, .financial-table td {{ padding: 10px 14px; text-align: left; border-bottom: 1px solid var(--border); }}
    .financial-table th {{ background: rgba(255,255,255,0.03); color: var(--muted); font-weight: 600; }}
    .financial-table tr:hover {{ background: rgba(255,255,255,0.02); }}
    .financial-table td.num {{ text-align: right; font-variant-numeric: tabular-nums; font-weight: 600; }}
    
    .alert-box {{ background: rgba(16, 185, 129, 0.08); border-left: 4px solid #10b981; padding: 14px 18px; border-radius: 0 8px 8px 0; margin-top: 24px; font-size: 13px; color: #cbd5e1; }}
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="badge">Studium Wykonalności i Wdrożenia (Behind-the-Meter)</div>
      <h1>Zajezdnia MPK Kraków – Wola Duchacka</h1>
      <p class="subtitle">
        Analiza numeryczna optymalizacji poboru mocy szczytowej floty 85 autobusów elektrycznych Solaris Urbino (52 stacje ładowania)
        z wykorzystaniem kontenerowego magazynu BESS 2,0 MW / 4,0 MWh w taryfie Tauron Dystrybucja B23.
      </p>
    </div>

    <!-- WSKAŹNIKI KPI -->
    <div class="grid-kpi">
      <div class="card">
        <div class="card-title">Moc Szczytowa Przed / Po</div>
        <div class="card-value">{kpi['Unmanaged_Peak_Load_MW']} &rarr; {kpi['Managed_Peak_Load_MW']} MW</div>
        <div class="card-diff diff-pos">&darr; Redukcja o {kpi['Peak_Shaved_MW']} MW ({kpi['Peak_Reduction_Percent']}%)</div>
      </div>
      <div class="card">
        <div class="card-title">Roczne Oszczędności</div>
        <div class="card-value">{kpi['Total_Annual_Savings_PLN']:,.0f} PLN</div>
        <div class="card-diff diff-pos">&check; Suma oszczędności B23 + URE + Arbitraż</div>
      </div>
      <div class="card">
        <div class="card-title">Wkład Własny Miasta</div>
        <div class="card-value">{kpi['Municipal_Equity_PLN']:,.0f} PLN</div>
        <div class="card-diff" style="color:#60a5fa">Dotacja FEnIKS 70%: {kpi['Total_CAPEX_PLN'] * 0.7:,.0f} PLN</div>
      </div>
      <div class="card">
        <div class="card-title">Zwrot z Inwestycji (SPB)</div>
        <div class="card-value">{kpi['Simple_Payback_Subsidized_Years']} roku</div>
        <div class="card-diff diff-pos">Bez dotacji: {kpi['Simple_Payback_Gross_Years']} lat | Trwałość: &gt;15 lat</div>
      </div>
    </div>

    <!-- WYKRES 24H PEAK SHAVING -->
    <div class="chart-section">
      <div class="chart-header">
        <h2 style="font-size:16px; font-weight:700;">Dobowy Profil Ścinania Szczytu Ładowania (24h)</h2>
        <div class="legend">
          <div class="legend-item"><span class="dot" style="background:#ef4444"></span> Pobór niezarządzany (pobyt floty)</div>
          <div class="legend-item"><span class="dot" style="background:#10b981"></span> Pobór z sieci po optymalizacji BESS</div>
          <div class="legend-item"><span class="dot" style="background:#3b82f6"></span> Poziom energii BESS (SoC)</div>
        </div>
      </div>

      <svg viewBox="0 0 {w} {h}" style="width:100%; height:auto; overflow:visible;">
        {''.join(grid_lines)}
        {''.join(y_labels)}
        <!-- Ścieżka poboru niezarządzanego -->
        <polyline fill="none" stroke="#ef4444" stroke-width="2.5" stroke-linejoin="round" points="{raw_line}" />
        <!-- Ścieżka poboru po BESS -->
        <polyline fill="none" stroke="#10b981" stroke-width="2.5" stroke-linejoin="round" points="{opt_line}" />
        <!-- Ścieżka SoC -->
        <polyline fill="none" stroke="#3b82f6" stroke-width="1.8" stroke-dasharray="4,3" points="{soc_line}" />
      </svg>
      <div style="margin-top:14px; font-size:12px; color:var(--muted); text-align:center;">
        Zwróć uwagę na ścięcie wieczornego szczytu (godz. 21:00 - 23:30) z 4,8 MW do bezpiecznego pułapu 3,2 MW oraz ładowanie nocne w dolinie taryfowej B23 (godz. 01:00 - 04:30).
      </div>
    </div>

    <!-- BILANS EKONOMICZNY I TARYFOWY -->
    <div class="card" style="margin-bottom:28px;">
      <h3 style="font-size:16px; font-weight:700; margin-bottom:12px;">Rozbicie Rocznych Korzyści Finansowych (Taryfa Tauron B23 + URE)</h3>
      <table class="financial-table">
        <thead>
          <tr>
            <th>Kategoria Korzyści</th>
            <th>Mechanizm Inżynieryjny</th>
            <th class="num">Wartość Miesięczna</th>
            <th class="num">Wartość Roczna</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Redukcja Mocy Zamówionej</strong></td>
            <td>Obniżenie mocy umownej z 5,2 MW do 3,6 MW (1,6 MW rezerwy szczytowej) przy stawce 21,50 zł/kW/m-c</td>
            <td class="num">{kpi['Monthly_Contracted_Power_Savings_PLN']:,.0f} PLN</td>
            <td class="num" style="color:#10b981">+{kpi['Annual_Contracted_Power_Savings_PLN']:,.0f} PLN</td>
          </tr>
          <tr>
            <td><strong>Uniknięta Opłata Mocowa URE</strong></td>
            <td>Ścięcie poboru w szczytowych godzinach URE (07:00-22:00 w dni robocze) wg stawki 141,20 zł/MWh</td>
            <td class="num">{kpi['Annual_Capacity_Fee_Savings_PLN']/12:,.0f} PLN</td>
            <td class="num" style="color:#10b981">+{kpi['Annual_Capacity_Fee_Savings_PLN']:,.0f} PLN</td>
          </tr>
          <tr>
            <td><strong>Arbitraż Taryfowy B23</strong></td>
            <td>Ładowanie magazynu w dolinie nocnej (380 zł/MWh) vs rozładowanie w drogiej strefie (720 zł/MWh)</td>
            <td class="num">{kpi['Annual_Tariff_Arbitrage_Savings_PLN']/12:,.0f} PLN</td>
            <td class="num" style="color:#10b981">+{kpi['Annual_Tariff_Arbitrage_Savings_PLN']:,.0f} PLN</td>
          </tr>
          <tr style="background: rgba(16, 185, 129, 0.05); font-weight: 700;">
            <td><strong>RAZEM KORZYŚCI NETTO</strong></td>
            <td>Roczny bilans oszczędności w budżecie MPK Kraków</td>
            <td class="num">{(kpi['Total_Annual_Savings_PLN']/12):,.0f} PLN</td>
            <td class="num" style="color:#10b981; font-size:15px;">+{kpi['Total_Annual_Savings_PLN']:,.0f} PLN/rok</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- STATUS PRAWNO-REGULACYJNY -->
    <div class="alert-box">
      <strong>Status Prawno-Regulacyjny Behind-the-Meter (BtM):</strong><br>
      Magazyn energii w Zajezdni Wola Duchacka jest instalowany jako instalacja odbiorcy końcowego Behind-the-Meter (za układem pomiarowo-rozliczeniowym).
      Zgodnie z znowelizowanym Prawem Energetycznym, magazyny energii na potrzeby własne o mocy do 10 MW <strong>nie wymagają koncesji Prezesa URE</strong> ani certyfikacji JGM (Jednostki Grafikowej Magazynu). Wszystkie wygenerowane oszczędności pochodzą z redukcji kosztów wewnętrznych (moc zamówiona, opłata mocowa, arbitraż).
      <br><br>
      <em>Ścieżka rozwojowa (2027+):</em> Po pilotażowym wdrożeniu BESS, MPK może przystąpić do agregacji w ramach DSR / DUB (Dostawca Usług Bilansujących) i oferować rezerwy mocy dla PSE S.A. na nowym Rynku Bilansującym.
    </div>
  </div>
</body>
</html>
"""

    with open(output_html, "w", encoding="utf-8") as f:
        f.write(html_content)


if __name__ == "__main__":
    run_wola_duchacka_case_study()
