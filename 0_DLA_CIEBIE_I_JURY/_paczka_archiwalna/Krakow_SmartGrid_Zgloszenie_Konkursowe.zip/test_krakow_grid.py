"""
Testy jednostkowe modułu analityczno-optymalizacyjnego Kraków EcoGrid
Konkurs Open Data App (Kraków 2026)
"""

import pytest
import numpy as np
import pandas as pd
from data_loader import KrakowDataLoader
from grid_optimizer import KrakowGridOptimizer


def test_krakow_data_loader_depots():
    loader = KrakowDataLoader()
    df = loader.get_mpk_depots()
    
    assert len(df) == 10
    assert "HUB-05" in df["id"].values
    assert any("Górka Narodowa" in name for name in df["name"].values)
    assert "lat" in df.columns and "lon" in df.columns
    # Sprawdzenie współrzędnych Krakowa
    assert (df["lat"] >= 49.9).all() and (df["lat"] <= 50.2).all()
    assert (df["lon"] >= 19.8).all() and (df["lon"] <= 20.2).all()
    assert (df["contracted_power_mw"] > 0).all()


def test_synthetic_hourly_profile_generation():
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=3)
    
    # 3 dni * 96 próbki na dobę (15 min) = 288 próbek
    assert len(df_prof) == 288
    assert "Grid_Demand_MW" in df_prof.columns
    assert (df_prof["Grid_Demand_MW"] > 0).all()
    assert "Tariff_PLN_MWh" in df_prof.columns


def test_peak_shaving_simulation():
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=2)
    
    optimizer = KrakowGridOptimizer(
        bess_capacity_mwh=6.0,
        bess_power_mw=2.5,
        rte=0.85
    )
    
    df_sim = optimizer.simulate_peak_shaving(df_prof)
    
    assert "Net_Grid_Demand_MW" in df_sim.columns
    assert "BESS_SoC_MWh" in df_sim.columns
    
    # Stan naładowania nie może przekroczyć pojemności ani spaść poniżej 0
    assert (df_sim["BESS_SoC_MWh"] <= 6.0 + 1e-4).all()
    assert (df_sim["BESS_SoC_MWh"] >= 0.0 - 1e-4).all()
    
    # Szczyt po optymalizacji musi być mniejszy lub równy szczytowi początkowemu
    assert df_sim["Net_Grid_Demand_MW"].max() <= df_sim["Grid_Demand_MW"].max() + 1e-5


def test_city_savings_calculation():
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=7)
    
    optimizer = KrakowGridOptimizer(
        bess_capacity_mwh=6.0,
        bess_power_mw=2.5
    )
    df_sim = optimizer.simulate_peak_shaving(df_prof)
    savings = optimizer.calculate_city_savings(df_sim)
    
    assert savings["Total_Annual_Savings_PLN"] > 0
    assert savings["Contracted_Power_Savings_PLN_Year"] >= 0
    assert savings["Capacity_Fee_Savings_PLN_Year"] >= 0
    assert 0 < savings["Simple_Payback_Years"] < 30
    assert 0 < savings["Subsidized_Payback_Years"] < 10
    assert savings["Municipal_Equity_PLN"] < savings["Total_CAPEX_PLN"]


def test_predictive_ai_training_and_signals():
    from predictive_ai import KrakowPredictiveDispatcher
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=4)
    
    dispatcher = KrakowPredictiveDispatcher(n_estimators=30)
    metrics = dispatcher.train(df_prof)
    
    assert "R2_Score" in metrics
    assert "MAE_MW" in metrics
    assert metrics["R2_Score"] > 0.60  # Model musi mieć sensowną jakość predykcji
    
    df_pred = dispatcher.generate_preemptive_dispatch(df_prof, target_peak_mw=3.5)
    assert "AI_Predicted_Demand_MW" in df_pred.columns
    assert "AI_Preemptive_Signal" in df_pred.columns
    assert len(df_pred) == len(df_prof)


def test_crisis_simulator_scenarios():
    from crisis_simulator import KrakowCrisisSimulator
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=2)
    sim = KrakowCrisisSimulator()
    
    # 1. Scenariusz mrozów
    res_freeze = sim.simulate_crisis(df_prof, "WINTER_FREEZE")
    assert res_freeze["Mitigated_Peak_MW"] < res_freeze["Raw_Crisis_Peak_MW"]
    assert res_freeze["Penalties_Avoided_PLN"] > 0
    
    # 2. Scenariusz awarii GPZ i trybu wyspowego (Blackout Islanding)
    res_blackout = sim.simulate_crisis(df_prof, "BLACKOUT_ISLAND", bess_power_mw=2.5, bess_cap_mwh=6.0)
    assert res_blackout["Mitigated_Peak_MW"] == 0.0  # Sieć odcięta
    assert res_blackout["Island_Hours_Secured"] > 1.0
    assert res_blackout["Penalties_Avoided_PLN"] > 0


def test_official_tariff_audit_integrity():
    from tariffs_audit import OFFICIAL_TARIFF_SOURCES, get_tariff_audit_summary
    assert "tauron_b23" in OFFICIAL_TARIFF_SOURCES
    assert "ure_capacity_fee" in OFFICIAL_TARIFF_SOURCES
    assert "pse_market_data" in OFFICIAL_TARIFF_SOURCES
    
    summary = get_tariff_audit_summary()
    assert "Taryfa" in summary
    assert "URE" in summary


def test_milp_optimization_solver():
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=2)
    optimizer = KrakowGridOptimizer(bess_capacity_mwh=6.0, bess_power_mw=2.5, rte=0.85)

    df_milp = optimizer.optimize_city_grid_milp(df_prof)

    assert "Net_Grid_Demand_MW" in df_milp.columns
    assert "Optimization_Engine" in df_milp.columns
    assert (df_milp["Net_Grid_Demand_MW"] >= 0).all()
    # SoC boundaries
    assert (df_milp["BESS_SoC_MWh"] <= 6.0 * 0.95 + 1e-3).all()
    assert (df_milp["BESS_SoC_MWh"] >= 6.0 * 0.10 - 1e-3).all()

    savings_milp = optimizer.calculate_city_savings(df_milp)
    assert savings_milp["Total_Annual_Savings_PLN"] > 0
    assert savings_milp["Peak_Reduction_MW"] > 0


def test_pse_api_integration_and_cache():
    loader = KrakowDataLoader()
    df_pse = loader.fetch_live_pse_prices(limit=10)

    assert len(df_pse) >= 10
    assert "Datetime" in df_pse.columns
    assert "RCE_PLN_MWh" in df_pse.columns
    assert (df_pse["RCE_PLN_MWh"] > 0).all()
    assert (df_pse["RCE_PLN_MWh"] < 4000).all()


def test_capacity_fee_peak_hour_filtering():
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=7)
    optimizer = KrakowGridOptimizer(bess_capacity_mwh=6.0, bess_power_mw=2.5)

    df_sim = optimizer.simulate_peak_shaving(df_prof)
    savings = optimizer.calculate_city_savings(df_sim)

    # Oszczędność opłaty mocowej musi być ściśle dodatnia i zgodna ze szczytami URE
    assert savings["Capacity_Fee_Savings_PLN_Year"] > 0
    assert savings["Contracted_Power_Savings_PLN_Year"] > 0


def test_decarbonization_fleet_and_bess_calculator():
    from decarbonization import KrakowDecarbonizationCalculator
    calc = KrakowDecarbonizationCalculator()

    # 1. Zero fleet edge case
    zero_res = calc.calculate_fleet_electrification_benefits(0)
    assert zero_res["Net_CO2_Avoided_Tons"] == 0.0
    assert zero_res["NOx_Avoided_KG"] == 0.0

    # 2. 85 buses (Wola Duchacka)
    wola_res = calc.calculate_fleet_electrification_benefits(85)
    assert wola_res["Net_CO2_Avoided_Tons"] > 0
    assert wola_res["NOx_Avoided_KG"] > 1000
    assert wola_res["PM10_Avoided_KG"] > 50
    assert wola_res["Equivalent_Trees_Planted"] > 10000

    # 3. BESS green shifting
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=3)
    optimizer = KrakowGridOptimizer(bess_capacity_mwh=6.0, bess_power_mw=2.5)
    df_sim = optimizer.simulate_peak_shaving(df_prof)

    bess_res = calc.calculate_bess_green_shifting_benefits(df_sim)
    assert bess_res["Annual_BESS_Throughput_MWh"] > 0
    assert bess_res["Annual_CO2_Avoided_By_BESS_Tons"] > 0

    # 4. Citywide impact (9 hubs)
    df_hubs = loader.get_mpk_depots()
    city_res = calc.get_citywide_clean_air_impact(df_hubs)
    assert city_res["Total_CO2_Avoided_Tons_Year"] > 2000
    assert city_res["Total_NOx_Eliminated_KG_Year"] > 30000
    assert city_res["SCT_Compliance_Score_Percent"] >= 95.0


def test_bess_degradation_lfp_vs_nmc():
    from bess_degradation import KrakowBessDegradationModel
    model_lfp = KrakowBessDegradationModel("LFP")
    model_nmc = KrakowBessDegradationModel("NMC")

    res_lfp = model_lfp.simulate_degradation_trajectory(capacity_mwh=6.0, cycles_per_day=1.1, years=15)
    res_nmc = model_nmc.simulate_degradation_trajectory(capacity_mwh=6.0, cycles_per_day=1.1, years=15)

    # LFP musi mieć wyższy SoH po 10 i 15 latach niż NMC
    assert res_lfp["SoH_After_10_Years_Percent"] > res_nmc["SoH_After_10_Years_Percent"]
    assert res_lfp["SoH_After_15_Years_Percent"] > res_nmc["SoH_After_15_Years_Percent"]
    assert res_lfp["Estimated_LCOS_PLN_MWh"] < res_nmc["Estimated_LCOS_PLN_MWh"]
    assert res_lfp["Thermal_Runaway_Temp_C"] > res_nmc["Thermal_Runaway_Temp_C"]

    # Trajektoria DataFrame
    df_traj = res_lfp["Trajectory_DataFrame"]
    assert len(df_traj) == 15
    assert (df_traj["SoH_Percent"] <= 100.0).all()
    assert (df_traj["SoH_Percent"] >= 50.0).all()

    # Tabela porównawcza
    df_comp = KrakowBessDegradationModel.compare_lfp_vs_nmc(capacity_mwh=6.0)
    assert len(df_comp) >= 7
    assert "LFP (Rekomendowane)" in df_comp.columns


def test_crisis_simulator_extended_scenarios():
    from crisis_simulator import KrakowCrisisSimulator
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=2)
    sim = KrakowCrisisSimulator()

    # 1. Dunkelflaute scenario
    res_dunkel = sim.simulate_crisis(df_prof, "DUNKELFLAUTE_PEAK", bess_power_mw=2.5, bess_cap_mwh=6.0)
    assert "Dunkelflaute" in res_dunkel["Scenario_Name"]
    assert res_dunkel["Mitigated_Peak_MW"] < res_dunkel["Raw_Crisis_Peak_MW"]
    assert res_dunkel["Penalties_Avoided_PLN"] > 0

    # 2. Cyber-physical SCADA disruption
    res_cyber = sim.simulate_crisis(df_prof, "CYBER_PHYSICAL_DISRUPTION", bess_power_mw=2.5, bess_cap_mwh=6.0)
    assert "SCADA" in res_cyber["Scenario_Name"]
    assert res_cyber["Mitigated_Peak_MW"] == 0.0
    assert res_cyber["Island_Hours_Secured"] > 1.0


def test_bess_degradation_edge_cases():
    from bess_degradation import KrakowBessDegradationModel
    model = KrakowBessDegradationModel("LFP")

    # Graniczne temperatury
    res_cold = model.simulate_degradation_trajectory(capacity_mwh=6.0, avg_cell_temp_c=-5.0, years=10)
    res_opt = model.simulate_degradation_trajectory(capacity_mwh=6.0, avg_cell_temp_c=20.0, years=10)
    res_hot = model.simulate_degradation_trajectory(capacity_mwh=6.0, avg_cell_temp_c=40.0, years=10)

    # Optimum 20°C zachowuje najwyższy SoH, mróz i upał degradują szybciej
    assert res_opt["SoH_After_10_Years_Percent"] > res_cold["SoH_After_10_Years_Percent"]
    assert res_hot["SoH_After_10_Years_Percent"] < res_cold["SoH_After_10_Years_Percent"]

    # Weryfikacja braku powtórzenia 'lat lat' w tabeli
    df_comp = KrakowBessDegradationModel.compare_lfp_vs_nmc(capacity_mwh=6.0)
    eol_lfp_row = df_comp[df_comp["Kryterium"].str.contains("Żywotność EOL")]["LFP (Rekomendowane)"].iloc[0]
    assert "lat lat" not in eol_lfp_row

    # Mała pojemność i wysokie obciążenie
    res_heavy = model.simulate_degradation_trajectory(capacity_mwh=1.0, cycles_per_day=3.0, avg_dod=0.95, years=10)
    assert res_heavy["SoH_After_10_Years_Percent"] < 80.0


def test_milp_energy_conservation_and_terminal_soc():
    """Weryfikacja ścisłego prawa zachowania energii w solwerze MILP na ostatnim kroku T-1."""
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=1)
    opt = KrakowGridOptimizer(bess_capacity_mwh=6.0, bess_power_mw=2.5, rte=0.85)

    df_milp = opt.optimize_city_grid_milp(df_prof)
    dt = 0.25
    eff = np.sqrt(0.85)

    # Weryfikacja ciągłości SoC na każdym kroku czasowym
    soc_prev = 6.0 * 0.5
    for t in range(len(df_milp)):
        ch = df_milp["BESS_Charge_MW"].iloc[t]
        dis = df_milp["BESS_Discharge_MW"].iloc[t]
        soc_actual = df_milp["BESS_SoC_MWh"].iloc[t]
        soc_expected = soc_prev + eff * dt * ch - (1.0 / eff) * dt * dis
        assert abs(soc_actual - soc_expected) < 1e-4
        soc_prev = soc_actual

    # Weryfikacja elastycznej relaksacji przy nierealistycznie niskim celu (0.5 MW)
    df_low_target = opt.optimize_city_grid_milp(df_prof, target_peak_mw=0.5)
    assert df_low_target["Optimization_Engine"].iloc[0] == "Global MILP / HiGHS Solver (Exact Math Optimum)"
    assert df_low_target["Peak_Reduced_MW"].max() > 1.5


def test_pse_api_multiday_tiling():
    """Weryfikacja poprawnego zwielokrotnienia danych PSE na horyzont wielodniowy."""
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=7, use_real_pse=True)

    assert len(df_prof) == 7 * 96
    assert "Price_Source" in df_prof.columns
    assert "PSE" in df_prof["Price_Source"].iloc[0]
    # Sprawdzenie czy ceny nie są stałymi wartościami syntetycznymi B23
    assert len(df_prof["Tariff_PLN_MWh"].unique()) > 2


def test_crisis_simulator_island_energy_conservation():
    """Weryfikacja wyczerpywania bufora BESS w trybie wyspowym bez fantomowej energii."""
    from crisis_simulator import KrakowCrisisSimulator
    loader = KrakowDataLoader()
    df_prof = loader.generate_synthetic_hourly_profile("DEP-03", days=7)
    sim = KrakowCrisisSimulator()

    res = sim.simulate_crisis(df_prof, "BLACKOUT_ISLAND", bess_power_mw=2.5, bess_cap_mwh=6.0)
    df_cr = res["Result_DataFrame"]

    total_island_energy = (df_cr["Emergency_Island_Supply_MW"] * 0.25).sum()
    # Całkowita dostarczona energia nie może przekroczyć pojemności baterii z marginesem RTE
    assert total_island_energy <= 6.0 * 0.90 + 1e-3
    assert res["Island_Hours_Secured"] > 2.0
    # Po wyczerpaniu zasilanie musi przejść w 0.0
    assert (df_cr["Emergency_Island_Supply_MW"].iloc[-96:] == 0.0).all()


def test_decarbonization_pm25_and_social_costs():
    """Weryfikacja obliczeń pyłu PM2.5 oraz zewnętrznych kosztów zdrowotnych wg EEA/WHO."""
    from decarbonization import KrakowDecarbonizationCalculator
    calc = KrakowDecarbonizationCalculator()

    res_fleet = calc.calculate_fleet_electrification_benefits(85)
    assert res_fleet["PM25_Avoided_KG"] > 0
    assert res_fleet["PM25_Avoided_KG"] < res_fleet["PM10_Avoided_KG"]  # Frakcja drobna to ~73% PM10
    assert res_fleet["External_Health_Savings_PLN"] > 100_000

    loader = KrakowDataLoader()
    df_hubs = loader.get_mpk_depots()
    city_impact = calc.get_citywide_clean_air_impact(df_hubs)
    assert city_impact["Total_PM25_Eliminated_KG_Year"] > 1000
    assert city_impact["Total_Health_Savings_PLN_Year"] > 1_500_000


def test_digital_twin_features_integrity():
    """Weryfikacja integralności kodu 3D Digital Twin: Financial HUD, Auto-Tour, Scenariusze dla Jury i Trajektorie."""
    import os
    index_path = os.path.join(os.path.dirname(__file__), "digital_twin", "index.html")
    assert os.path.exists(index_path)

    with open(index_path, "r", encoding="utf-8") as f:
        html = f.read()

    # 1. Live Financial HUD & Ticker
    assert "financial-hud-widget" in html
    assert "live-financial-pln" in html
    assert "fin-peak-val" in html
    assert "fin-capacity-val" in html
    assert "fin-arbitrage-val" in html
    assert "dailySavingsAccumulator" in html

    # 2. Interactive Jury Demo Scenarios
    assert "jury-scenarios-banner" in html
    assert "hero-scen-1" in html
    assert "hero-scen-2" in html
    assert "hero-scen-3" in html
    assert "runJuryScenario" in html

    # 3. Cinematic Auto-Tour Presentation
    assert "btn-auto-tour" in html
    assert "cinema-tour-overlay" in html
    assert "AUTO_TOUR_STEPS" in html
    assert "applyAutoTourStep" in html

    # 4. Glowing Trajectories & Street Arteries
    assert "CORRIDORS_DATA" in html
    assert "Aleje Trzech Wieszczów" in html
    assert "trajectoryPulses" in html
    assert "toggleTrajectories" in html
    assert "corridor-badges-container" in html

    # 5. 1st-Person Onboard Cockpit Mode & Immersion
    assert "btn-cockpit-toggle" in html
    assert "cockpit-hud-overlay" in html
    assert "toggleCockpitCamera" in html
    assert "cockpitCameraActive" in html
    assert "cockpit-dash" in html
    assert "setDriverSpeedPreset" in html
    assert "adjustDriverSpeed" in html
    assert "turnDriverHead" in html

    # 6. Real Kraków Geography, River Wisła & Planty Map Texture
    assert "getDistanceToWisla" in html
    assert "WISLA_POINTS" in html
    assert "BRIDGES_DATA" in html
    assert "createKrakowMapTexture" in html
    assert "Planty Krakowskie" in html
    assert "Plus Jakarta Sans" in html

    # 7. Real-time Live Clock & Sun Calculation
    assert "isLiveClock" in html
    assert "btn-live-clock" in html
    assert "updateClockUI" in html

    # 8. Anti-Clumping Label De-cluttering & Collapsible Financial HUD
    assert "badgePositions" in html
    assert "toggleFinancialWidget" in html


def test_pdf_documentation_generation():
    """Weryfikacja obecności i poprawności wygenerowanej dokumentacji konkursowej PDF."""
    import os
    pdf_path = os.path.join(os.path.dirname(__file__), "0_DLA_CIEBIE_I_JURY", "04_DOKUMENTACJA_TECHNICZNA.pdf")
    if not os.path.exists(pdf_path):
        pdf_path = os.path.join(os.path.dirname(__file__), "_DO_USUNIECIA", "KRAKOW_ECOGRID_DOKUMENTACJA_KONKURSOWA.pdf")
    html_path = os.path.join(os.path.dirname(__file__), "_DO_USUNIECIA", "KRAKOW_ECOGRID_DOKUMENTACJA_KONKURSOWA.html")

    assert os.path.exists(pdf_path), "Plik PDF dokumentacji nie istnieje!"
    assert os.path.getsize(pdf_path) > 100_000, "Plik PDF jest zbyt mały (<100 KB)!"

    assert os.path.exists(html_path)
    with open(html_path, "r", encoding="utf-8") as f:
        doc_html = f.read()

    # Sprawdzenie obecności kluczowych sekcji konkursowych
    assert "Centrum Obsługi Informatycznej UMK" in doc_html
    assert "3 240 000 PLN" in doc_html
    assert "Taryfa Tauron B23" in doc_html or "Tauron Dystrybucja" in doc_html
    assert "48/2025" in doc_html
    assert "Zabłocie 20.22" in doc_html
    assert "21/21 testów jednostkowych" in doc_html
    assert "zestaw 21 testów" in doc_html


def test_scenario_and_crisis_state_hygiene():
    """Weryfikacja braku wycieków stanu w 3D: uniwersalny reset siatek, ochrona temperatury i czyszczenie Auto-Tour."""
    import os
    index_path = os.path.join(os.path.dirname(__file__), "digital_twin", "index.html")
    with open(index_path, "r", encoding="utf-8") as f:
        html = f.read()

    # Weryfikacja uniwersalnego resetu linii WN i tarcz microgrid w triggerCrisis
    assert "gridLines.forEach(l => {" in html
    assert "l.mesh.material.color.setHex(0x00f0ff);" in html
    assert "h.userData.shield.material.opacity = 0.0;" in html

    # Weryfikacja stopAutoTour powrotu do stanu NORMAL
    assert 'triggerCrisis("NORMAL")' in html
    assert "if (VEHICLES_DATA[0]) VEHICLES_DATA[0].charging = false;" in html

    # Weryfikacja kompletności metryk we wszystkich 3 scenariuszach
    assert "fin-annual-val" in html
    assert "fin-arbitrage-val" in html


def test_mpk_transit_routes_continuity():
    """Weryfikacja ciaglosci geometrycznej tras MPK (brak przeskokow > 25m, probkowanie luku co 10m)."""
    import os
    import json
    import math

    routes_path = os.path.join(os.path.dirname(__file__), "digital_twin", "data", "krakow_routes.json")
    assert os.path.exists(routes_path), "Brak pliku krakow_routes.json!"

    with open(routes_path, "r", encoding="utf-8") as f:
        routes_data = json.load(f)

    # Wymagane linie z Rozkazu 1
    required_lines = ["50", "4", "52", "8", "179", "169", "128", "139"]
    for r_id in required_lines:
        assert r_id in routes_data, f"Brak trasy dla linii {r_id}!"
        r_info = routes_data[r_id]
        pts = r_info.get("points", [])
        assert len(pts) >= 100, f"Linia {r_id} ma zbyt malo punktow ({len(pts)})!"

        # Weryfikacja przeskokow miedzy sasiednimi punktami (1 unit w scenie = 100 metrow)
        for i in range(len(pts) - 1):
            p0 = pts[i]
            p1 = pts[i + 1]
            dx_m = (p1["x"] - p0["x"]) * 100.0
            dz_m = (p1["z"] - p0["z"]) * 100.0
            dist_m = math.hypot(dx_m, dz_m)

            # Odleglosc NIE MOZE przekraczac 25 metrow (probkowanie co 10m)
            assert dist_m <= 25.0, (
                f"Wykryto przeskok {dist_m:.2f} m > 25 m na linii {r_id} miedzy punktami {i} i {i+1}!"
            )

        # Weryfikacja domknięcia pętli trasy (ostatni punkt do pierwszego)
        p_last = pts[-1]
        p_first = pts[0]
        dx_wrap = (p_first["x"] - p_last["x"]) * 100.0
        dz_wrap = (p_first["z"] - p_last["z"]) * 100.0
        dist_wrap = math.hypot(dx_wrap, dz_wrap)
        assert dist_wrap <= 25.0, (
            f"Wykryto przeskok domknięcia pętli {dist_wrap:.2f} m > 25 m na linii {r_id} ({dist_wrap:.2f} m > 25 m)!"
        )


def test_orders_architectural_and_ui_integrity():
    """Weryfikacja autentyczności zabytków 3D, filtrowania budynków OSM i responsywności UI na 1280px."""
    import os

    index_path = os.path.join(os.path.dirname(__file__), "digital_twin", "index.html")
    assert os.path.exists(index_path)

    with open(index_path, "r", encoding="utf-8") as f:
        html = f.read()

    # 1. Rozkaz 2: Symbole Krakowa (Sukiennice, Mariacki, Wawel, Wysokościowce)
    assert "createKrakowLandmarks" in html
    assert "Attyka Polska" in html or "attyka" in html
    assert "SŁYNNA ZŁOTA KORONA KRÓLEWSKA NA HEJNALICY (#d4af37)" in html or "0xd4af37" in html
    assert "SŁYNNA KAPLICA ZYGMUNTOWSKA ZE ZŁOTĄ KOPUŁĄ (#d4af37)" in html
    assert "DZIEDZINIEC ARKADOWY" in html.upper() or "dziedziniec arkadowy" in html.lower()
    assert "UNITY TOWER" in html.upper()
    assert "K1 BŁĘKITEK" in html.upper() or "K1" in html
    assert "TAURON ARENA" in html.upper()

    # 2. Rozkaz 2: Ochrona zabytków przed kolizją z generycznymi bryłami OSM
    assert "distRynekCenter" in html or "distRynek" in html
    assert "distWawel" in html

    # 3. Rozkaz 3: Ostrość i odblokowany zoom
    assert "anisotropy" in html
    assert "controls.minDistance = 4" in html
    assert "camera.near = 0.1" in html
    assert "centerDarkTexture" in html

    # 4. Rozkaz 4: Etykiety tekstowe nagłówka na 1280px NIE mogą być ukryte display:none
    assert "@media (max-width: 1280px) {\n      .btn-txt-label { display: none !important; }" not in html
    assert "Bilans Mocy" in html
    assert "Audyt URE" in html
    assert "Dekarbonizacja" in html
    assert "KPO" in html
    assert "Auto-Patrol" in html
    assert "Ścieżki" in html

    # 5. Metropolitalny Bliźniak 2.5D: Węzeł Górka Narodowa i Klaster Zabłocie 20.22
    assert "HUB-05" in html
    assert "Pętla Górka Narodowa" in html
    assert "Zabłocie 20.22" in html or "ZABŁOCIE" in html.upper()
    assert "+8 876 PLN" in html
    assert "3 240 000 PLN" in html
    assert "-2.85 MW" in html
    assert "formatScadaPLN" in html
    assert "@media (max-width: 1280px) {\n      .ticker-annual { display: none !important; }" not in html
    assert "createGabledRoof" in html


def test_webgis_maplibre_architecture_and_launcher():
    """Weryfikacja architektury Web-GIS MapLibre GL JS, integralności danych WGS84 i launcherów projektu."""
    import os
    import json

    base_dir = os.path.dirname(__file__)
    map_html_path = os.path.join(base_dir, "digital_twin", "map.html")
    gis_data_path = os.path.join(base_dir, "digital_twin", "data", "krakow_webgis_data.json")
    serve_py_path = os.path.join(base_dir, "digital_twin", "serve.py")
    project_bat_path = os.path.join(base_dir, "Uruchom_Krakow_Konkurs.bat")

    # 1. Plik map.html
    assert os.path.exists(map_html_path), "Brak pliku digital_twin/map.html!"
    assert os.path.getsize(map_html_path) > 10_000, "Plik map.html jest zbyt mały!"
    with open(map_html_path, "r", encoding="utf-8") as f:
        html = f.read()

    # Weryfikacja nowej architektury SCADA SLD & Executive Cockpit (po wycofaniu MapLibre)
    assert "sld-view" in html
    assert "cockpit-view" in html
    assert "GPZ Kurdwanów" in html or "GPZ KURDWANÓW" in html
    assert "Executive Cockpit" in html
    assert "provenance-modal" in html
    assert "PLN" in html or "zł" in html or "zl" in html
    assert "selectHub" in html
    assert "applyScenario" in html

    # 2. Plik krakow_webgis_data.json
    assert os.path.exists(gis_data_path), "Brak pliku krakow_webgis_data.json!"
    with open(gis_data_path, "r", encoding="utf-8") as f:
        gis_data = json.load(f)

    hubs = gis_data["hubs"]
    assert len(hubs) == 10, f"Oczekiwano 10 węzłów BESS, znaleziono {len(hubs)}!"
    hub_ids = [h["id"] for h in hubs]
    for required_id in ["DEP-01", "DEP-02", "DEP-03", "DEP-04", "DEP-05", "HUB-01", "HUB-02", "HUB-03", "HUB-04", "HUB-05"]:
        assert required_id in hub_ids, f"Brak węzła {required_id} w danych Web-GIS!"

    routes = gis_data["transit_routes"]
    assert len(routes) == 8, f"Oczekiwano 8 tras MPK, znaleziono {len(routes)}!"
    for r_id in ["50", "4", "52", "8", "169", "179", "128", "139"]:
        assert r_id in routes, f"Brak trasy {r_id} w danych Web-GIS!"
        coords = routes[r_id]["coordinates"]
        assert len(coords) >= 100, f"Trasa {r_id} ma zbyt mało współrzędnych!"
        # Sprawdzenie współrzędnych WGS84 Krakowa
        for lon, lat in coords[::50]:
            assert 19.80 <= lon <= 20.20, f"Błędna długość geograficzna {lon} na trasie {r_id}!"
            assert 49.95 <= lat <= 50.15, f"Błędna szerokość geograficzna {lat} na trasie {r_id}!"

    # 3. 5 GPZów i sieć przesyłowa 110 kV
    assert len(gis_data["gpzs"]) == 5
    assert len(gis_data["grid_lines"]) >= 5

    # 4. Klaster Zabłocie 20.22 (Miejsce finału)
    landmarks = gis_data["landmarks"]
    assert any("ZABLOCIE" in lm["id"] for lm in landmarks)

    # 5. Serwer HTTP serve.py
    assert os.path.exists(serve_py_path)
    with open(serve_py_path, "r", encoding="utf-8") as f:
        serve_code = f.read()
    assert "map.html" in serve_code
    assert "Access-Control-Allow-Origin" in serve_code

    # 6. Skrypt startowy w katalogu projektu
    launcher_exists = os.path.exists(project_bat_path) or os.path.exists(os.path.join(base_dir, "0_DLA_CIEBIE_I_JURY", "01_URUCHOM_SCADA.bat"))
    assert launcher_exists, "Brak oficjalnego skryptu startowego SCADA!"


def test_numerical_grid_balance_and_physics_constraints():
    """
    Rygorystyczny test numeryczny praw fizyki i bilansu mocy:
    1. I Prawo Kirchhoffa w węźle: P_grid - P_ch + P_dis = P_demand (błąd < 1e-5 MW).
    2. Ograniczenia mocy falownika PCS: 0 <= P_ch <= P_max, 0 <= P_dis <= P_max.
    3. Ograniczenia stanu naładowania magazynu: 0 <= SoC <= Capacity_max.
    4. Ścisła redukcja szczytu: max(P_grid) <= max(P_demand).
    5. Asercja spójności ekonomicznej: suma składowych = Total_Annual_Savings_PLN.
    """
    loader = KrakowDataLoader()
    # Test na profilu wielodniowym (3 dni = 288 kroków po 15 min)
    df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=3)
    
    cap_mwh = 4.0
    p_max_mw = 2.0
    optimizer = KrakowGridOptimizer(
        bess_capacity_mwh=cap_mwh,
        bess_power_mw=p_max_mw,
        rte=0.88,
        contracted_power_rate_pln_kw_month=21.50
    )

    # 1. Sprawdzenie dla solwera MILP / HiGHS
    df_milp = optimizer.optimize_city_grid_milp(df_prof, target_peak_mw=3.2)
    
    p_demand = df_milp["Grid_Demand_MW"].values
    p_grid = df_milp["Net_Grid_Demand_MW"].values
    p_ch = df_milp["BESS_Charge_MW"].values
    p_dis = df_milp["BESS_Discharge_MW"].values
    soc = df_milp["BESS_SoC_MWh"].values

    # Bilans mocy w każdym kroku czasowym
    power_imbalance = np.abs(p_grid - p_ch + p_dis - p_demand)
    assert np.max(power_imbalance) < 1e-4, f"Naruszenie bilansu mocy! Maks błąd: {np.max(power_imbalance)}"

    # Ograniczenia falownika
    assert (p_ch >= -1e-5).all() and (p_ch <= p_max_mw + 1e-4).all()
    assert (p_dis >= -1e-5).all() and (p_dis <= p_max_mw + 1e-4).all()

    # Granice pojemności bufora BESS
    assert (soc >= -1e-4).all() and (soc <= cap_mwh + 1e-4).all()

    # Redukcja piku
    assert np.max(p_grid) <= np.max(p_demand) + 1e-4

    # Asercja spójności ekonomicznej
    savings = optimizer.calculate_city_savings(df_milp)
    calculated_sum = (
        savings["Contracted_Power_Savings_PLN_Year"] +
        savings["Capacity_Fee_Savings_PLN_Year"] +
        savings["Tariff_Arbitrage_Savings_PLN_Year"]
    )
    assert abs(savings["Total_Annual_Savings_PLN"] - calculated_sum) < 0.05
    assert savings["Monthly_Contracted_Power_Savings_PLN"] > 0
    assert savings["Contracted_Power_Savings_Gross_PLN_Year"] >= savings["Contracted_Power_Savings_PLN_Year"]


