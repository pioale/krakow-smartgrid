"""
Kraków EcoGrid Optimizer: Numeryczny Algorytm Optymalizacyjny (MILP) i Peak Shaving
Dla Miejskiej Infrastruktury Transportowej i Komunalnej Krakowa.
Wykorzystuje programowanie liniowe/mieszane (SciPy HiGHS) oraz regulatory czasu rzeczywistego.
"""

import numpy as np
import pandas as pd
from scipy.optimize import linprog


class KrakowGridOptimizer:
    def __init__(
        self,
        bess_capacity_mwh: float = 6.0,
        bess_power_mw: float = 2.5,
        rte: float = 0.85,
        capacity_fee_rate_pln_mwh: float = 141.20,  # Opłata mocowa dla taryfy B/C w godzinach szczytowych
        contracted_power_rate_pln_kw_month: float = 28.50,  # Stała opłata sieciowa za moc zamówioną Tauron B23
        behind_the_meter: bool = True,  # Rozdział PPE: Behind-the-Meter vs VPP
        bms_aux_power_kw: float = 20.0  # Pobór HVAC kontenera bateryjnego przy mrozach
    ):
        self.capacity_mwh = bess_capacity_mwh
        self.power_mw = bess_power_mw
        self.rte = rte
        self.capacity_fee_rate = capacity_fee_rate_pln_mwh
        self.contracted_power_rate = contracted_power_rate_pln_kw_month
        self.behind_the_meter = behind_the_meter
        self.bms_aux_power_kw = bms_aux_power_kw

    def calculate_bms_thermal_load(self, ambient_temp_c: float) -> float:
        """
        Zwraca moc grzania/chłodzenia kontenera BESS (kW).
        Przy -15°C ogniwa LFP nie zamarzają, lecz pobór HVAC kontenera rośnie do 15-25 kW na węzeł.
        """
        if ambient_temp_c < 5.0:
            return 3.0 + (5.0 - ambient_temp_c) * 1.0  # Przy -15C -> 23 kW
        elif ambient_temp_c > 25.0:
            return 3.0 + (ambient_temp_c - 25.0) * 0.8
        return 2.5

    def get_cold_derating_factor(self, cell_temp_c: float) -> float:
        """
        Derating mocy ładowania przy niskich temperaturach (ochrona przed lithium plating).
        """
        if cell_temp_c < 0.0:
            return 0.35
        elif cell_temp_c < 15.0:
            return 0.70
        return 1.0

    def simulate_peak_shaving(self, df_profile: pd.DataFrame, target_peak_mw: float = None) -> pd.DataFrame:
        """
        Symuluje działanie bufora bateryjnego redukującego szczytowy pobór z miejskiej sieci (Heurystyczny kontroler MPC).
        Algorytm ładuje magazyn w nocy (gdy zapotrzebowanie jest niskie, a energia tania)
        i rozładowuje podczas pików ładowania floty EV, aby nie przekroczyć target_peak_mw.
        """
        df = df_profile.copy()
        raw_demand = df['Grid_Demand_MW'].values
        n_steps = len(df)
        dt = 0.25  # 15 minut = 0.25 h
        
        eff = np.sqrt(self.rte)
        
        if target_peak_mw is None:
            # Optymalny próg ścięcia szczytów: redukcja do ok. 80-85% piku pierwotnego
            target_peak_mw = max(raw_demand.mean(), raw_demand.max() - min(self.power_mw * 0.75, raw_demand.max() * 0.25))
            
        battery_charge = np.zeros(n_steps)
        battery_discharge = np.zeros(n_steps)
        soc = np.zeros(n_steps)
        net_grid_demand = np.zeros(n_steps)
        
        current_soc = self.capacity_mwh * 0.5  # początkowo 50%
        
        for t in range(n_steps):
            load = raw_demand[t]
            t_rate = df['Tariff_PLN_MWh'].iloc[t]
            hour = df['Datetime'].iloc[t].hour + df['Datetime'].iloc[t].minute / 60.0
            
            # Dynamiczny bufor bezpieczeństwa SoC_min: 25% w godzinach szczytu (06:00-21:00), 10% w nocy
            is_peak_hours = (hour >= 6.0 and hour <= 21.0)
            soc_floor = self.capacity_mwh * (0.25 if is_peak_hours else 0.10)

            # Strategia 1: Ścinanie szczytu (Peak Shaving) - redukcja opłaty za moc zamówioną
            if load > target_peak_mw and current_soc > soc_floor:
                needed_p = load - target_peak_mw
                avail_p = min(needed_p, self.power_mw)
                max_energy_avail = max(0.0, (current_soc - soc_floor) * eff)
                p_discharge = min(avail_p, max_energy_avail / dt)
                battery_discharge[t] = p_discharge
                current_soc -= (p_discharge / eff) * dt
            # Strategia 2: Arbitraż strefowy i unikanie opłaty mocowej w szczycie dziennym
            elif t_rate >= 700.0 and current_soc > max(soc_floor + self.capacity_mwh * 0.1, self.capacity_mwh * 0.35) and load > 0.8:
                avail_p = min(self.power_mw * 0.4, max(0.0, (current_soc - soc_floor) * eff / dt))
                battery_discharge[t] = avail_p
                current_soc -= (avail_p / eff) * dt
            # Strategia 3: Inteligentne doładowanie w dolinach taryfowych i poza szczytem
            elif (t_rate <= 400.0 or (hour >= 13.0 and hour <= 15.0)) and current_soc < self.capacity_mwh:
                room_p = max(0.0, target_peak_mw - load)
                if room_p > 0.05:
                    p_charge = min(self.power_mw, room_p, (self.capacity_mwh - current_soc) / (eff * dt))
                    battery_charge[t] = p_charge
                    current_soc += (p_charge * eff) * dt
                
            current_soc = max(0.0, min(self.capacity_mwh, current_soc))
            soc[t] = current_soc
            net_grid_demand[t] = load + battery_charge[t] - battery_discharge[t]
            
        df['Net_Grid_Demand_MW'] = net_grid_demand
        df['BESS_Charge_MW'] = battery_charge
        df['BESS_Discharge_MW'] = battery_discharge
        df['BESS_SoC_MWh'] = soc
        df['Peak_Reduced_MW'] = np.maximum(0.0, df['Grid_Demand_MW'] - df['Net_Grid_Demand_MW'])
        df['Optimization_Engine'] = 'Real-Time Heuristic / MPC'
        
        return df

    def optimize_city_grid_milp(self, df_profile: pd.DataFrame, target_peak_mw: float = None) -> pd.DataFrame:
        """
        Globalny Solwer Programowania Liniowego (MILP / HiGHS) dla całego horyzontu czasowego.
        Matematycznie minimalizuje sumę kosztów:
        min [ Koszt Energii B23 + Opłata Mocowa URE + Opłata za Moc Zamówioną Tauron ]
        przy zachowaniu ograniczeń bilansu mocy, sprawności RTE i pojemności bufora BESS.
        """
        df = df_profile.copy()
        raw_demand = df['Grid_Demand_MW'].values
        t_rates = df['Tariff_PLN_MWh'].values
        T = len(df)
        dt = 0.25  # 15 minut
        eff = np.sqrt(self.rte)
        
        # Oznaczenie godzin opłaty mocowej URE (dni robocze 07:00 - 22:00)
        if 'Datetime' in df.columns:
            hours = df['Datetime'].dt.hour + df['Datetime'].dt.minute / 60.0
            day_of_week = df['Datetime'].dt.dayofweek
            is_capacity_peak = (day_of_week < 5) & (hours >= 7.0) & (hours < 22.0)
        else:
            is_capacity_peak = np.ones(T, dtype=bool)
            
        c_cap_rate = np.where(is_capacity_peak, self.capacity_fee_rate, 0.0)
        
        # Zmienne decyzyjne:
        # [0 .. T-1]: p_ch (Moc ładowania BESS)
        # [T .. 2T-1]: p_dis (Moc rozładowania BESS)
        # [2T .. 3T-1]: soc (Stan energii w buforze MWh)
        # [3T .. 4T-1]: p_grid (Moc pobierana z sieci)
        # [4T]: P_peak (Maksymalna moc szczytowa zamówiona)
        # [4T + 1] (opcjonalnie): slack_peak (elastyczna relaksacja celu szczytowego)
        has_target = target_peak_mw is not None
        n_vars = 4 * T + (2 if has_target else 1)
        idx_ch = 0
        idx_dis = T
        idx_soc = 2 * T
        idx_grid = 3 * T
        idx_peak = 4 * T
        idx_slack = 4 * T + 1 if has_target else None
        
        # Wektor kosztów c:
        # 1. Koszt energii i opłaty mocowej w horyzoncie symulacji:
        c = np.zeros(n_vars)
        for t in range(T):
            c[idx_grid + t] = (t_rates[t] + c_cap_rate[t]) * dt
            
        # 2. Koszt mocy szczytowej w taryfie dystrybucyjnej B23 (Tauron Dystrybucja):
        # W taryfie B23 składnik stały stawki sieciowej rozliczany jest w cyklu MIESIĘCZNYM [PLN/kW/miesiąc].
        # Jeden 15-minutowy szczyt poboru w danym miesiącu determinuje opłatę za moc umowną/przekroczenie na cały miesiąc.
        # W optymalizacji dobowego lub kilkudniowego profilu szczytowego (który decyduje o szczycie miesiąca),
        # waga P_peak w funkcji celu musi odpowiadać pełnemu kosztowi miesięcznemu za każdy MW mocy szczytowej:
        # c_peak = contracted_power_rate [PLN/kW/m-c] * 1000 [kW/MW] * liczba_miesięcy (min. 1 miesiąc)
        months_spanned = max(1.0, (T * dt) / 730.0)  # Średnio 730h w miesiącu
        c[idx_peak] = self.contracted_power_rate * 1000.0 * months_spanned
        if has_target:
            c[idx_slack] = 1e6  # Wysoka kara za przekroczenie docelowego pułapu (miękkie ograniczenie)
        
        # Równania bilansu (A_eq, b_eq)
        A_eq = []
        b_eq = []
        
        # 1. Bilans węzła: p_grid[t] - p_ch[t] + p_dis[t] = raw_demand[t]
        for t in range(T):
            row = np.zeros(n_vars)
            row[idx_grid + t] = 1.0
            row[idx_ch + t] = -1.0
            row[idx_dis + t] = 1.0
            A_eq.append(row)
            b_eq.append(raw_demand[t])
            
        # 2. Dynamika stanu naładowania SoC:
        # soc[t] reprezentuje stan energii w buforze na KONIEC przedziału t.
        soc_init = self.capacity_mwh * 0.5

        # Krok t = 0: soc[0] = soc_init + eff * dt * p_ch[0] - (1/eff) * dt * p_dis[0]
        row0 = np.zeros(n_vars)
        row0[idx_soc] = 1.0
        row0[idx_ch] = -eff * dt
        row0[idx_dis] = (1.0 / eff) * dt
        A_eq.append(row0)
        b_eq.append(soc_init)

        # Kroki t = 1 .. T-1: soc[t] = soc[t-1] + eff * dt * p_ch[t] - (1/eff) * dt * p_dis[t]
        for t in range(1, T):
            row = np.zeros(n_vars)
            row[idx_soc + t] = 1.0
            row[idx_soc + t - 1] = -1.0
            row[idx_ch + t] = -eff * dt
            row[idx_dis + t] = (1.0 / eff) * dt
            A_eq.append(row)
            b_eq.append(0.0)

        # Nierówności (A_ub, b_ub)
        A_ub = []
        b_ub = []

        # 1. Ścinanie szczytu: p_grid[t] - P_peak <= 0
        for t in range(T):
            row = np.zeros(n_vars)
            row[idx_grid + t] = 1.0
            row[idx_peak] = -1.0
            A_ub.append(row)
            b_ub.append(0.0)

        if has_target:
            # P_peak - slack_peak <= target_peak_mw
            row_lim = np.zeros(n_vars)
            row_lim[idx_peak] = 1.0
            row_lim[idx_slack] = -1.0
            A_ub.append(row_lim)
            b_ub.append(float(target_peak_mw))

        # 2. Warunek cykliczności: soc[T-1] >= 0.45 * capacity_mwh (nie wyładowywać bufora na koniec)
        row_cyc = np.zeros(n_vars)
        row_cyc[idx_soc + T - 1] = -1.0
        A_ub.append(row_cyc)
        b_ub.append(-self.capacity_mwh * 0.45)

        # Granice zmiennych: Dynamiczny bufor bezpieczeństwa SoC_min >= 25% w godzinach szczytu (06:00-21:00), 10% w nocy
        soc_max = self.capacity_mwh * 0.95  # 95% maks dla przedłużenia cyklu życia LFP
        soc_bounds = []
        for t in range(T):
            if 'Datetime' in df.columns:
                h = df['Datetime'].iloc[t].hour + df['Datetime'].iloc[t].minute / 60.0
                is_peak_h = (h >= 6.0) and (h <= 21.0)
            else:
                is_peak_h = True
            min_soc_t = self.capacity_mwh * (0.25 if is_peak_h else 0.10)
            soc_bounds.append((min_soc_t, soc_max))

        bounds = (
            [(0.0, self.power_mw)] * T +          # p_ch
            [(0.0, self.power_mw)] * T +          # p_dis
            soc_bounds +                          # soc (dynamiczny bufor bezpieczeństwa)
            [(0.0, None)] * T +                   # p_grid
            [(0.0, None)]                         # P_peak
        )
        if has_target:
            bounds.append((0.0, None))             # slack_peak

        res = linprog(
            c,
            A_ub=np.array(A_ub),
            b_ub=np.array(b_ub),
            A_eq=np.array(A_eq),
            b_eq=np.array(b_eq),
            bounds=bounds,
            method='highs'
        )

        if res.success:
            x = res.x
            df['Net_Grid_Demand_MW'] = x[idx_grid:idx_grid + T]
            df['BESS_Charge_MW'] = x[idx_ch:idx_ch + T]
            df['BESS_Discharge_MW'] = x[idx_dis:idx_dis + T]
            df['BESS_SoC_MWh'] = x[idx_soc:idx_soc + T]
            df['Peak_Reduced_MW'] = np.maximum(0.0, df['Grid_Demand_MW'] - df['Net_Grid_Demand_MW'])
            df['Optimization_Engine'] = 'Global MILP / HiGHS Solver (Exact Math Optimum)'
        else:
            # Fallback na sprawdzoną heurystykę jeśli solwer napotkał problem
            return self.simulate_peak_shaving(df_profile, target_peak_mw)

        return df

    def calculate_city_savings(
        self,
        df_sim: pd.DataFrame,
        capex_pln_per_mwh: float = 950000.0,
        subsidy_ratio: float = 0.70,
        bess_reliability_factor: float = 0.98
    ) -> dict:
        """
        Kalkuluje roczne korzyści finansowe dla budżetu Krakowa i MPK:
        1. Oszczędność na mocy zamówionej (stała opłata przesyłowa Tauron B23 rozliczana miesięcznie).
           UWAGA INŻYNIERSKA: W taryfie B23 moc umowna rozliczana jest co miesiąc. Pojedyncze
           przekroczenie w miesiącu powoduje naliczenie kary i unieważnia oszczędność w danym miesiącu.
           Dlatego model uwzględnia współczynnik dyspozycyjności BESS (domyślnie 98% przy rezerwie modułowej N+1).
        2. Oszczędność na opłacie mocowej (dokładne godziny szczytu URE 07:00-22:00 w dni robocze).
        3. Arbitraż taryfowy (B23 strefa szczytowa vs nocna).
        4. Zwrot z inwestycji (Gross Payback oraz z 70% dotacją unijną FEnIKS/KPO).
        """
        raw_peak_mw = df_sim['Grid_Demand_MW'].max()
        opt_peak_mw = df_sim['Net_Grid_Demand_MW'].max()
        peak_shaved_mw = max(0.0, raw_peak_mw - opt_peak_mw)
        
        # 1. Redukcja mocy zamówionej (PLN / miesiąc oraz PLN / rok)
        # Taryfa B23: składnik stały stawki sieciowej naliczany co miesiąc od mocy umownej
        monthly_contracted_power_savings = peak_shaved_mw * 1000.0 * self.contracted_power_rate
        contracted_power_savings_gross = monthly_contracted_power_savings * 12.0
        contracted_power_savings = contracted_power_savings_gross * bess_reliability_factor
        
        # 2. Redukcja opłaty mocowej URE
        # Podstawa prawna: Informacja Prezesa URE nr 48/2025 - opłata mocowa obowiązuje
        # wyłącznie w dni robocze w godzinach 07:00-22:00.
        dt = 0.25
        if 'Datetime' in df_sim.columns:
            hours = df_sim['Datetime'].dt.hour + df_sim['Datetime'].dt.minute / 60.0
            day_of_week = df_sim['Datetime'].dt.dayofweek
            is_peak_hour = (day_of_week < 5) & (hours >= 7.0) & (hours < 22.0)
            discharge_peak_mwh = (df_sim['BESS_Discharge_MW'].values[is_peak_hour] * dt).sum()
        else:
            discharge_peak_mwh = (df_sim['BESS_Discharge_MW'] * dt).sum() * (15.0 / 24.0) * (5.0 / 7.0)
            
        days_in_sample = max(1.0, len(df_sim) / 96.0)
        annual_energy_shaved_mwh = discharge_peak_mwh * (365.0 / days_in_sample)
        capacity_fee_savings = annual_energy_shaved_mwh * self.capacity_fee_rate
        
        # 3. Arbitraż taryfowy
        # Oszczędność = koszt zakupu energii bez BESS minus koszt po zoptymalizowanym ładowaniu
        cost_without_bess = (df_sim['Grid_Demand_MW'] * df_sim['Tariff_PLN_MWh'] * dt).sum()
        cost_with_bess = (df_sim['Net_Grid_Demand_MW'] * df_sim['Tariff_PLN_MWh'] * dt).sum()
        tariff_savings_period = cost_without_bess - cost_with_bess
        annual_tariff_savings = tariff_savings_period * (365.0 / days_in_sample)
        
        total_annual_savings = contracted_power_savings + capacity_fee_savings + annual_tariff_savings
        
        # Nakłady inwestycyjne (CAPEX) dla kontenera bateryjnego LFP 2026 (turnkey ze stacją trafo i PCS)
        total_capex = self.capacity_mwh * capex_pln_per_mwh
        net_capex_subsidized = total_capex * (1.0 - subsidy_ratio)
        
        simple_payback_years = total_capex / total_annual_savings if total_annual_savings > 0 else 99.0
        subsidized_payback_years = net_capex_subsidized / total_annual_savings if total_annual_savings > 0 else 99.0
        
        return {
            "Raw_Peak_MW": round(float(raw_peak_mw), 2),
            "Opt_Peak_MW": round(float(opt_peak_mw), 2),
            "Peak_Reduction_MW": round(float(peak_shaved_mw), 2),
            "Monthly_Contracted_Power_Savings_PLN": round(float(monthly_contracted_power_savings), 2),
            "Contracted_Power_Savings_Gross_PLN_Year": round(float(contracted_power_savings_gross), 2),
            "Contracted_Power_Savings_PLN_Year": round(float(contracted_power_savings), 2),
            "Capacity_Fee_Savings_PLN_Year": round(float(capacity_fee_savings), 2),
            "Tariff_Arbitrage_Savings_PLN_Year": round(float(annual_tariff_savings), 2),
            "Total_Annual_Savings_PLN": round(float(total_annual_savings), 2),
            "Total_CAPEX_PLN": round(float(total_capex), 2),
            "Municipal_Equity_PLN": round(float(net_capex_subsidized), 2),
            "Simple_Payback_Years": round(float(simple_payback_years), 1),
            "Subsidized_Payback_Years": round(float(subsidized_payback_years), 1)
        }
