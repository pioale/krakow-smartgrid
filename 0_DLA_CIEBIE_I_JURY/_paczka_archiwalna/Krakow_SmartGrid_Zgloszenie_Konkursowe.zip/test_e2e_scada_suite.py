"""
Kraków SmartGrid Enterprise Web-GIS SCADA Control Center
End-to-End (E2E) Opaque-Box Automated Test Suite

4-Tier Test Architecture:
- Tier 1: Feature Coverage (50 tests, 5 per feature across 10 features)
- Tier 2: Boundary & Corner Cases (50 tests, 5 per feature across 10 features)
- Tier 3: Cross-Feature Combinations (10 interaction tests)
- Tier 4: Real-World Scenarios (4 comprehensive walkthrough tests)
Total: 114 test cases

Authoritative Specifications:
- PROJECT.md
- ORIGINAL_REQUEST.md
- 100-Point Jury Acceptance Checklist (explorer_survey_jury/handoff.md)
- Official Excel Model: 0_DLA_CIEBIE_I_JURY/KRAKOW_SMARTGRID_MODEL_FINANSOWY_WOLA_DUCHACKA.xlsx
- Formal PDF: Krakow_SmartGrid_Opis_Projektu_i_Celu.pdf
"""

import os
import re
import sys
import json
import time
import socket
import threading
import urllib.request
import urllib.error
import pytest
import pandas as pd
import openpyxl
from bs4 import BeautifulSoup
import pypdf

# Paths
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
SCADA_HTML_PATH = os.path.join(ROOT_DIR, "krakow_smartgrid_scada.html")
MIRROR_MAP_PATH = os.path.join(ROOT_DIR, "digital_twin", "map.html")
SERVER_PY_PATH = os.path.join(ROOT_DIR, "server.py")
BAT_LAUNCHER_PATH = os.path.join(ROOT_DIR, "0_DLA_CIEBIE_I_JURY", "01_URUCHOM_SCADA.bat")
if not os.path.exists(BAT_LAUNCHER_PATH):
    BAT_LAUNCHER_PATH = os.path.join(ROOT_DIR, "Uruchom_Krakow_Konkurs.bat")
EXCEL_MODEL_PATH = os.path.join(ROOT_DIR, "0_DLA_CIEBIE_I_JURY", "02_MODEL_FINANSOWY_EXCEL.xlsx")
if not os.path.exists(EXCEL_MODEL_PATH):
    EXCEL_MODEL_PATH = os.path.join(ROOT_DIR, "0_DLA_CIEBIE_I_JURY", "05_MODEL_FINANSOWY_WOLA_DUCHACKA.xlsx")
if not os.path.exists(EXCEL_MODEL_PATH):
    EXCEL_MODEL_PATH = os.path.join(ROOT_DIR, "0_DLA_CIEBIE_I_JURY", "KRAKOW_SMARTGRID_MODEL_FINANSOWY_WOLA_DUCHACKA.xlsx")

PDF_SUMMARY_PATH = os.path.join(ROOT_DIR, "_formalnosci_etap1_archive", "01_OPIS_PROJEKTU_2_STRONY_UMK.pdf")
if not os.path.exists(PDF_SUMMARY_PATH):
    PDF_SUMMARY_PATH = os.path.join(ROOT_DIR, "_archiwum_robocze", "robocze_dokumenty", "01_OPIS_PROJEKTU_2_STRONY_UMK.pdf")
if not os.path.exists(PDF_SUMMARY_PATH):
    PDF_SUMMARY_PATH = os.path.join(ROOT_DIR, "0_DLA_CIEBIE_I_JURY", "03_DOKUMENTACJA_TECHNICZNA.pdf")

PDF_CONTEST_PATH = os.path.join(ROOT_DIR, "0_DLA_CIEBIE_I_JURY", "03_DOKUMENTACJA_TECHNICZNA.pdf")
if not os.path.exists(PDF_CONTEST_PATH):
    PDF_CONTEST_PATH = os.path.join(ROOT_DIR, "_archiwum_robocze", "robocze_dokumenty", "01_OPIS_PROJEKTU_2_STRONY_UMK.pdf")

ZIP_SUBMISSION_PATH = os.path.join(ROOT_DIR, "_formalnosci_etap1_archive", "08_PACZKA_ZGLOSZENIOWA_DO_WYSLANIA.zip")
if not os.path.exists(ZIP_SUBMISSION_PATH):
    ZIP_SUBMISSION_PATH = os.path.join(ROOT_DIR, "_archiwum_robocze", "robocze_dokumenty", "08_PACZKA_ZGLOSZENIOWA_DO_WYSLANIA.zip")
KPI_JSON_PATH = os.path.join(ROOT_DIR, "data", "wola_duchacka_kpi_summary.json")
TIMESERIES_CSV_PATH = os.path.join(ROOT_DIR, "data", "wola_duchacka_simulation_timeseries.csv")
WEBGIS_DATA_PATH = os.path.join(ROOT_DIR, "digital_twin", "data", "krakow_webgis_data.js")

# Helper to retrieve active SCADA HTML content
def get_scada_html():
    """Returns content of primary SCADA html if present, or mirror map.html for fallback inspection."""
    if os.path.exists(SCADA_HTML_PATH):
        with open(SCADA_HTML_PATH, "r", encoding="utf-8") as f:
            return f.read()
    elif os.path.exists(MIRROR_MAP_PATH):
        with open(MIRROR_MAP_PATH, "r", encoding="utf-8") as f:
            return f.read()
    else:
        raise FileNotFoundError("Neither krakow_smartgrid_scada.html nor digital_twin/map.html exists.")

def get_scada_soup():
    return BeautifulSoup(get_scada_html(), "html.parser")

def find_free_port(start_port=8980):
    for p in range(start_port, start_port + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(('127.0.0.1', p)) != 0:
                return p
    return 8980

# Fixture for running test HTTP server
@pytest.fixture(scope="session")
def live_server():
    from server import KrakowMapHandler, ThreadingSimpleServer
    port = find_free_port()
    server_address = ('127.0.0.1', port)
    httpd = ThreadingSimpleServer(server_address, KrakowMapHandler)
    server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    server_thread.start()
    time.sleep(0.4)
    base_url = f"http://127.0.0.1:{port}"
    yield base_url
    httpd.shutdown()
    httpd.server_close()
    server_thread.join(timeout=2)


# ==============================================================================
# TIER 1: FEATURE COVERAGE (50 Test Cases: 5 tests per feature for 10 features)
# ==============================================================================

class TestTier1FeatureCoverage:
    """Tier 1: Comprehensive verification of nominal behavior for all 10 inventoried features."""

    # ---------------- Feature 1: SCADA Master Data Engine ----------------
    def test_tier1_feat1_master_data_json_schema(self):
        """Verifies presence, validity, and required keys of wola_duchacka_kpi_summary.json."""
        assert os.path.exists(KPI_JSON_PATH), f"Missing master KPI dataset: {KPI_JSON_PATH}"
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        required_keys = [
            "Hub_ID", "Hub_Name", "EV_Buses_Count", "EV_Chargers_Count",
            "Grid_Connection_Capacity_MW", "Unmanaged_Peak_Load_MW",
            "Managed_Peak_Load_MW", "Peak_Shaved_MW", "BESS_Capacity_MWh",
            "BESS_Power_MW", "Total_Annual_Savings_PLN", "Municipal_Equity_PLN"
        ]
        for key in required_keys:
            assert key in data, f"Key '{key}' missing from master KPI schema"

    def test_tier1_feat1_timeseries_96_intervals(self):
        """Verifies 96 15-minute simulation intervals for the 24h cycle in the timeseries dataset."""
        assert os.path.exists(TIMESERIES_CSV_PATH), f"Missing timeseries dataset: {TIMESERIES_CSV_PATH}"
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        assert len(df) >= 96, f"Expected at least 96 time intervals, got {len(df)}"
        required_cols = [
            "Datetime", "Pobor_Niezarzadzany_MW", "Pobor_Zoptymalizowany_Siec_MW",
            "Moc_Ladowania_BESS_MW", "Moc_Rozladowania_BESS_MW", "Stan_Energii_BESS_MWh"
        ]
        for col in required_cols:
            assert col in df.columns, f"Column '{col}' missing from simulation timeseries"

    def test_tier1_feat1_financial_kpis_accuracy(self):
        """Verifies financial KPIs match audited contest figures (+795 721 PLN, 1.14M equity, 1.4y payback)."""
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        assert abs(data["Total_Annual_Savings_PLN"] - 795721.07) < 1.0, "Total savings deviation exceeds 1 PLN"
        assert abs(data["Municipal_Equity_PLN"] - 1140000.0) < 1.0, "Municipal equity deviation exceeds 1 PLN"
        assert abs(data["Simple_Payback_Subsidized_Years"] - 1.4) < 0.2, "Payback period deviation exceeds 0.2 years"

    def test_tier1_feat1_bess_lfp_technical_specs(self):
        """Verifies BESS technical parameters (4.0 MWh, 2.0 MW, LiFePO4 chemistry, RTE 0.88)."""
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        assert data["BESS_Capacity_MWh"] == 4.0, f"Expected 4.0 MWh, got {data['BESS_Capacity_MWh']}"
        assert data["BESS_Power_MW"] == 2.0, f"Expected 2.0 MW, got {data['BESS_Power_MW']}"
        assert "LFP" in data["BESS_Technology"] or "LiFePO4" in data["BESS_Technology"]
        assert data["BESS_Round_Trip_Efficiency"] == 0.88

    def test_tier1_feat1_webgis_geojson_layers(self):
        """Verifies authentic Krakow WebGIS layer payload with hubs, GPZ substations, and transit lines."""
        assert os.path.exists(WEBGIS_DATA_PATH), f"Missing WebGIS data file: {WEBGIS_DATA_PATH}"
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "window.KRAKOW_WEBGIS_DATA" in content, "KRAKOW_WEBGIS_DATA object not declared in JS"
        assert "hubs" in content and "gpzs" in content and "transit_routes" in content

    # ---------------- Feature 2: Top Ribbon & KPI Tickers ----------------
    def test_tier1_feat2_header_title_and_branding(self):
        """Verifies SCADA application header contains official title and branding."""
        html = get_scada_html()
        assert "Kraków SmartGrid" in html, "Application title 'Kraków SmartGrid' not found in HTML"
        assert "inteligentna platforma" in html.lower() or "scada" in html.lower(), "Subtitle/branding not found"

    def test_tier1_feat2_umk_opendata_badge(self):
        """Verifies UMK Open Data 2026 competition badge is present in header/ribbon."""
        html = get_scada_html()
        soup = BeautifulSoup(html, "html.parser")
        text = soup.get_text()
        assert any(term in text for term in ["UMK", "Open Data", "Centrum Obsługi Informatycznej", "Kapituła"]), \
            "UMK Open Data competition affiliation not displayed"

    def test_tier1_feat2_live_kpi_metric_tickers(self):
        """Verifies top ribbon presents key telemetry metrics elements."""
        soup = get_scada_soup()
        text = soup.get_text()
        assert "795" in text or "840" in text, "Annual savings ticker not rendered"
        assert "MW" in text, "Power capacity ticker not rendered"
        assert "MWh" in text, "Energy capacity ticker not rendered"

    def test_tier1_feat2_financial_ticker_exact_values(self):
        """Verifies ribbon or metric cards display audited financial indicators (795 721 zł, 1,37 MW)."""
        html = get_scada_html()
        # Look for 795 721 or 1.37 / 1,37 MW in markup or script
        assert ("795" in html and "721" in html) or "795721" in html or "840 000" in html, \
            "Expected 795 721 PLN savings indicator in SCADA markup"

    def test_tier1_feat2_top_ribbon_action_buttons(self):
        """Verifies top ribbon includes quick action buttons (Excel, PDF, Scenarios, or Bookmarks)."""
        soup = get_scada_soup()
        buttons = soup.find_all(["button", "a"])
        button_texts = [b.get_text().strip().lower() for b in buttons]
        # At least one launcher/action button must exist
        assert any("excel" in t or "pdf" in t or "scenariusz" in t or "wola" in t or "export" in t or "pobierz" in t for t in button_texts), \
            "Action buttons for Excel/PDF/Bookmarks missing from interface"

    # ---------------- Feature 3: Central Dark Web-GIS Map ----------------
    def test_tier1_feat3_webgis_map_container_present(self):
        """Verifies map DOM container element (#map or #webgl-container) is defined."""
        soup = get_scada_soup()
        map_el = soup.find(id=re.compile(r"map|webgl-container|canvas-container", re.I))
        assert map_el is not None, "Map container (#map / #webgl-container) not found in DOM"

    def test_tier1_feat3_webgis_ten_bess_hubs_rendered(self):
        """Verifies dataset defines 10 BESS hubs covering Krakow transport infrastructure."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "DEP-01" in content and "DEP-02" in content and "HUB-05" in content
        # Ensure 10 hubs in dataset
        hubs_matches = re.findall(r'"id":\s*"(DEP-\d+|HUB-\d+)"', content)
        assert len(set(hubs_matches)) >= 10, f"Expected 10 unique hubs, found {len(set(hubs_matches))}"

    def test_tier1_feat3_webgis_five_gpz_substations(self):
        """Verifies 5 110/15 kV GPZ Tauron substations exist in WebGIS data."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        gpz_ids = ["GPZ-01", "GPZ-02", "GPZ-03", "GPZ-04", "GPZ-05"]
        for gid in gpz_ids:
            assert gid in content, f"Substation {gid} missing from WebGIS dataset"

    def test_tier1_feat3_webgis_110kv_feeder_lines(self):
        """Verifies 110 kV transmission lines connecting GPZ to hubs are defined in GeoJSON."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "grid_lines" in content or "LINE-GPZ" in content, "110 kV grid feeder lines not found in dataset"

    def test_tier1_feat3_webgis_authentic_gtfs_routes(self):
        """Verifies authentic ZTP GTFS lines (50, 52, 4, 8, 169, 179) are included."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        expected_routes = ["50", "169", "179"]
        for r in expected_routes:
            assert f'"{r}"' in content or f"Linia {r}" in content, f"GTFS route {r} missing from WebGIS dataset"

    # ---------------- Feature 4: Wola Duchacka Micro-GIS ----------------
    def test_tier1_feat4_wola_duchacka_centroid_coordinates(self):
        """Verifies depot centroid matches geographic coordinates (approx 50.0165 - 50.0242 N, 19.9595 - 19.9612 E)."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "50.0165" in content or "50.0242" in content or "Wola Duchacka" in content, \
            "Wola Duchacka coordinates not located in spatial dataset"

    def test_tier1_feat4_wola_duchacka_depot_polygon(self):
        """Verifies Wola Duchacka depot polygon or facility boundary is present."""
        html = get_scada_html()
        assert "Wola Duchacka" in html or "Walerego Sławka" in html, \
            "Depot facility reference missing from SCADA view"

    def test_tier1_feat4_wola_duchacka_52_chargers_indexed(self):
        """Verifies depot configuration accounts for high-power charging stations (52 / 117 stations)."""
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            kpi = json.load(f)
        assert kpi["EV_Chargers_Count"] in [52, 117], f"Unexpected charger count: {kpi['EV_Chargers_Count']}"

    def test_tier1_feat4_wola_duchacka_fleet_85_buses(self):
        """Verifies fleet electrification scope covers 85 operational e-buses (121 total fleet)."""
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            kpi = json.load(f)
        assert kpi["EV_Buses_Count"] in [85, 121], f"Unexpected bus fleet count: {kpi['EV_Buses_Count']}"

    def test_tier1_feat4_wola_duchacka_bess_facility_specs(self):
        """Verifies 4 MWh / 2 MW BESS facility container specification."""
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            kpi = json.load(f)
        assert kpi["BESS_Capacity_MWh"] == 4.0
        assert kpi["BESS_Power_MW"] == 2.0

    # ---------------- Feature 5: 24-Hour Timeline Scrubber ----------------
    def test_tier1_feat5_timeline_scrubber_slider_element(self):
        """Verifies 24h timeline scrubber input/slider exists in the DOM."""
        soup = get_scada_soup()
        slider = soup.find("input", {"type": "range"}) or soup.find(id=re.compile(r"time|scrubber|slider|timeline", re.I))
        assert slider is not None, "Timeline range slider element not found in DOM"

    def test_tier1_feat5_timeline_scrubber_96_steps(self):
        """Verifies timeline scrubber supports 15-minute resolution (step count >= 24 or 96)."""
        soup = get_scada_soup()
        slider = soup.find("input", {"type": "range"})
        if slider and slider.has_attr("max"):
            max_val = int(slider["max"])
            assert max_val in [23, 24, 95, 96, 1440], f"Unexpected slider range: {max_val}"
        else:
            # Check script for 96 interval definitions
            html = get_scada_html()
            assert "96" in html or "15" in html, "15-minute / 96-interval logic not referenced in code"

    def test_tier1_feat5_multiseries_curve_baseline_managed(self):
        """Verifies chart/curve series for baseline demand vs managed grid demand."""
        html = get_scada_html()
        # Ensure references to baseline, optimized/managed demand, and battery
        assert any(term in html.lower() for term in ["baseline", "niezarzadzany", "pobor", "managed", "zoptymalizowany"]), \
            "Load curve series definitions missing from SCADA application"

    def test_tier1_feat5_peak_shaving_delta_at_2130(self):
        """Verifies timeseries data shows peak reduction (from 5.04 MW to 3.68 MW) at evening peak (21:00-23:00)."""
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        peak_row = df.loc[df["Pobor_Niezarzadzany_MW"].idxmax()]
        assert peak_row["Pobor_Niezarzadzany_MW"] >= 4.8, f"Max unmanaged peak expected >= 4.8 MW, got {peak_row['Pobor_Niezarzadzany_MW']}"
        assert peak_row["Pobor_Zoptymalizowany_Siec_MW"] <= 3.8, f"Managed peak exceeded ceiling: {peak_row['Pobor_Zoptymalizowany_Siec_MW']}"

    def test_tier1_feat5_night_valley_charging_window(self):
        """Verifies BESS charging occurs in cheap B23 night valley (01:00 - 05:00)."""
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        # Check night hours for non-zero charge power
        night_df = df[(df["Datetime"].str.contains(r" 0[1-4]:", regex=True))]
        assert (night_df["Moc_Ladowania_BESS_MW"] > 0).any(), "No BESS charging observed during night valley"

    # ---------------- Feature 6: Hardware Battery Telemetry HUD ----------------
    def test_tier1_feat6_battery_hud_soc_radial_dial(self):
        """Verifies presence of battery SOC telemetry widget or dial."""
        html = get_scada_html()
        assert any(term in html.lower() for term in ["soc", "bateria", "battery", "stan energii", "naładowania"]), \
            "Battery SOC indicator not found in SCADA view"

    def test_tier1_feat6_battery_hud_pcs_inverter_power(self):
        """Verifies PCS bidirectional inverter power readout is modeled."""
        html = get_scada_html()
        assert any(term in html.lower() for term in ["pcs", "inverter", "falownik", "2.0 mw", "2.5 mw", "moc baterii"]), \
            "Inverter power telemetry not defined in HUD"

    def test_tier1_feat6_battery_hud_liquid_cooling_temp(self):
        """Verifies thermal management / liquid cooling telemetry presence."""
        html = get_scada_html()
        assert any(term in html for term in ["°C", "temp", "Thermal", "chłodzenie", "24."]), \
            "Thermal monitoring / temperature readout missing from telemetry"

    def test_tier1_feat6_battery_hud_15y_degradation_curve(self):
        """Verifies 15-year LFP degradation trajectory (Ecker/Schmalstieg model: >81% at 15y)."""
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            kpi = json.load(f)
        assert kpi["BESS_SoH_After_10_Years_Percent"] > 84.0, "10-year SoH below expected LFP baseline"
        assert kpi["BESS_SoH_After_15_Years_Percent"] > 80.0, "15-year SoH below 80% EOL threshold"

    def test_tier1_feat6_battery_hud_lifepo4_safety_rating(self):
        """Verifies battery chemistry explicitly states non-flammable LFP."""
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            kpi = json.load(f)
        assert "LiFePO4" in kpi["BESS_Technology"] or "LFP" in kpi["BESS_Technology"]

    # ---------------- Feature 7: Scenario Stress-Testing Engine ----------------
    def test_tier1_feat7_scenario_switcher_buttons_present(self):
        """Verifies scenario switcher UI elements are defined in HTML."""
        html = get_scada_html()
        assert any(term in html.lower() for term in ["scenariusz", "scenario", "stress", "kryzys", "tryb operacyjny"]), \
            "Scenario switcher component missing from interface"

    def test_tier1_feat7_scenario_smartgrid_ems_default(self):
        """Verifies default nominal operating mode (SmartGrid EMS / Dzień Standardowy)."""
        html = get_scada_html()
        assert any(term in html.lower() for term in ["smartgrid ems", "standard", "optymalny", "normalny"]), \
            "Nominal SmartGrid mode missing from scenario registry"

    def test_tier1_feat7_scenario_baseline_overload_504mw(self):
        """Verifies Baseline Overload scenario representation (unmanaged 5.04 MW peak)."""
        html = get_scada_html()
        assert "5.04" in html or "5,04" in html or "overload" in html.lower() or "przeciążenie" in html.lower() or "brak bess" in html.lower(), \
            "Baseline unmanaged overload scenario not represented"

    def test_tier1_feat7_scenario_winter_freeze_protection(self):
        """Verifies Winter Freeze (-15°C) scenario representation."""
        html = get_scada_html()
        assert any(term in html.lower() for term in ["zima", "freeze", "-15", "mróz", "winter"]), \
            "Winter freeze scenario missing from registry"

    def test_tier1_feat7_scenario_blackout_islanding_mode(self):
        """Verifies Blackout Islanding microgrid mode representation."""
        html = get_scada_html()
        assert any(term in html.lower() for term in ["blackout", "wyspow", "island", "awaria gpz"]), \
            "Blackout microgrid islanding scenario missing from registry"

    def test_tier1_feat7_scenario_dunkelflaute_market_arbitrage(self):
        """Verifies Dunkelflaute KSE market price surge scenario representation."""
        html = get_scada_html()
        assert any(term in html.lower() for term in ["dunkelflaute", "ceny kse", "szczyt cenowy", "rce"]), \
            "Dunkelflaute market crisis scenario missing from registry"

    # ---------------- Feature 8: Audited Excel & PDF Modal ----------------
    def test_tier1_feat8_excel_preview_modal_present(self):
        """Verifies modal dialog or view for inspecting audited Excel calculation is defined."""
        soup = get_scada_soup()
        modal = soup.find(id=re.compile(r"modal|dialog|excel-viewer", re.I)) or soup.find(class_=re.compile(r"modal|overlay", re.I))
        assert modal is not None or "modal" in get_scada_html().lower(), "Audited Excel modal dialog not found in DOM"

    def test_tier1_feat8_excel_file_download_link(self):
        """Verifies presence of direct link or button to download the official .xlsx financial model."""
        html = get_scada_html()
        assert ".xlsx" in html or "MODEL_FINANSOWY" in html or "Pobierz Model Excel" in html or "download" in html.lower(), \
            "Link or action to download Excel model missing"

    def test_tier1_feat8_pdf_summary_download_link(self):
        """Verifies presence of direct link or action to download the 2-page project summary PDF."""
        html = get_scada_html()
        assert ".pdf" in html or "Pobierz Opis Projektu" in html or "Opis_Projektu" in html, \
            "Link or action to download project summary PDF missing"

    def test_tier1_feat8_zip_package_download_link(self):
        """Verifies presence of submission zip archive link or reference."""
        html = get_scada_html()
        assert ".zip" in html or "Paczka" in html or "zgłoszeni" in html.lower() or "dossier" in html.lower(), \
            "Submission zip package reference missing from application"

    def test_tier1_feat8_excel_multi_sheet_tabs_rendered(self):
        """Verifies official Excel model file is valid and contains expected calculation sheets."""
        assert os.path.exists(EXCEL_MODEL_PATH), f"Excel model missing: {EXCEL_MODEL_PATH}"
        wb = openpyxl.load_workbook(EXCEL_MODEL_PATH, read_only=True)
        sheet_names = wb.sheetnames
        expected_sheets = ["Zalozenia_i_Zrodla", "Profil_Mocy_24h_15min", "Kalkulacja_Oszczednosci", "Analiza_Inwestycyjna_DCF"]
        for s in expected_sheets:
            assert s in sheet_names, f"Sheet '{s}' missing from official Excel model"

    # ---------------- Feature 9: Open Data Provenance Badges ----------------
    def test_tier1_feat9_provenance_badge_umk_open_data(self):
        """Verifies attribution badge for UMK Open Data portal (otwartedane.um.krakow.pl)."""
        html = get_scada_html()
        assert "otwartedane.um.krakow.pl" in html or "Otwarte Dane UMK" in html, \
            "UMK Open Data provenance reference missing"

    def test_tier1_feat9_provenance_badge_msip_krakow(self):
        """Verifies attribution badge for MSIP Kraków spatial infrastructure (msip.krakow.pl)."""
        html = get_scada_html()
        assert "msip.krakow.pl" in html or "MSIP" in html, \
            "MSIP Kraków spatial data provenance reference missing"

    def test_tier1_feat9_provenance_badge_ztp_gtfs(self):
        """Verifies attribution badge for ZTP Kraków authentic GTFS transport data."""
        html = get_scada_html()
        assert "ZTP" in html or "GTFS" in html, \
            "ZTP Kraków GTFS transit provenance reference missing"

    def test_tier1_feat9_provenance_badge_pse_market_esi(self):
        """Verifies attribution badge for PSE S.A. energy market data (raporty.pse.pl / e-SI)."""
        html = get_scada_html()
        assert "PSE" in html or "e-SI" in html or "RCE" in html, \
            "PSE S.A. energy market provenance reference missing"

    def test_tier1_feat9_provenance_inspector_modal_dialog(self):
        """Verifies data provenance inspector or details panel is referenced."""
        html = get_scada_html()
        assert any(term in html.lower() for term in ["źródł", "provenance", "inspektor", "dane miejskie", "otwarte dane"]), \
            "Data provenance inspector modal/panel missing"

    # ---------------- Feature 10: Launchers & Server Integration ----------------
    def test_tier1_feat10_server_file_exists_and_configured(self):
        """Verifies server.py exists and handles port binding and threading."""
        assert os.path.exists(SERVER_PY_PATH), "server.py not found in project root"
        with open(SERVER_PY_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "ThreadingSimpleServer" in content or "SimpleHTTPRequestHandler" in content
        assert "8080" in content, "Default port 8080 not configured in server.py"

    def test_tier1_feat10_server_default_landing_page(self):
        """Verifies server serves web application without routing error."""
        with open(SERVER_PY_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "krakow" in content.lower() and ".html" in content.lower(), \
            "server.py does not define landing HTML URL"

    def test_tier1_feat10_server_mime_types_registered(self):
        """Verifies server.py registers proper MIME types for glb, json, geojson, js, xlsx, and pdf."""
        with open(SERVER_PY_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "guess_type" in content or "mimetypes" in content, "server.py lacks custom MIME type handler"

    def test_tier1_feat10_launcher_bat_script_present(self):
        """Verifies double-click launcher script Uruchom_Krakow_Konkurs.bat exists."""
        assert os.path.exists(BAT_LAUNCHER_PATH), "Uruchom_Krakow_Konkurs.bat missing from root"
        with open(BAT_LAUNCHER_PATH, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        assert "server.py" in content, "Batch launcher does not invoke server.py"

    def test_tier1_feat10_scada_entrypoint_html_present(self):
        """Verifies SCADA application entrypoint file exists in workspace."""
        has_primary = os.path.exists(SCADA_HTML_PATH)
        has_mirror = os.path.exists(MIRROR_MAP_PATH)
        assert has_primary or has_mirror, "Neither krakow_smartgrid_scada.html nor digital_twin/map.html exists"


# ==============================================================================
# TIER 2: BOUNDARY & CORNER CASES (50 Test Cases: 5 tests per feature)
# ==============================================================================

class TestTier2BoundaryCases:
    """Tier 2: Verification of edge conditions, extreme ranges, boundary values, and fault tolerance."""

    # ---------------- Feature 1 Boundaries ----------------
    def test_tier2_feat1_empty_dataset_handling(self):
        """Ensures logic handles empty or truncated timeseries array without uncaught exception."""
        df = pd.DataFrame(columns=["Datetime", "Pobor_Niezarzadzany_MW"])
        assert len(df) == 0
        # Check calculation function handles empty dataframe
        from grid_optimizer import KrakowGridOptimizer
        opt = KrakowGridOptimizer(bess_capacity_mwh=4.0, bess_power_mw=2.0)
        # Empty simulation should not crash
        try:
            res = opt.calculate_city_savings(pd.DataFrame({
                "Net_Grid_Demand_MW": [0.0],
                "Grid_Demand_MW": [0.0],
                "BESS_Discharge_MW": [0.0],
                "Tariff_PLN_MWh": [380.0]
            }))
            assert "Total_Annual_Savings_PLN" in res
        except Exception as e:
            pytest.fail(f"Grid optimizer crashed on boundary input: {e}")

    def test_tier2_feat1_negative_power_rejection(self):
        """Verifies demand values are strictly non-negative in timeseries profile."""
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        assert (df["Pobor_Niezarzadzany_MW"] >= 0).all(), "Negative unmanaged load found in timeseries"
        assert (df["Pobor_Zoptymalizowany_Siec_MW"] >= 0).all(), "Negative net grid demand found in timeseries"

    def test_tier2_feat1_out_of_bounds_timestamps(self):
        """Verifies timeseries timestamps adhere strictly to ISO format YYYY-MM-DD HH:MM:SS."""
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        parsed = pd.to_datetime(df["Datetime"], errors="coerce")
        assert not parsed.isna().any(), "Invalid or malformed datetime strings detected in simulation data"

    def test_tier2_feat1_corrupted_json_resilience(self):
        """Verifies that invalid JSON structure in local cache is catchable with standard JSONDecodeError."""
        bad_json = '{"Hub_ID": "DEP-01", "unclosed": '
        with pytest.raises(json.JSONDecodeError):
            json.loads(bad_json)

    def test_tier2_feat1_schema_type_integrity(self):
        """Verifies data types in KPI summary are strictly numeric where required."""
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            kpi = json.load(f)
        assert isinstance(kpi["Total_Annual_Savings_PLN"], (int, float))
        assert isinstance(kpi["Municipal_Equity_PLN"], (int, float))
        assert isinstance(kpi["BESS_Capacity_MWh"], (int, float))
        assert isinstance(kpi["BESS_Power_MW"], (int, float))

    # ---------------- Feature 2 Boundaries ----------------
    def test_tier2_feat2_negative_savings_formatting(self):
        """Verifies UI or script formats zero or boundary savings properly."""
        html = get_scada_html()
        # Ensure currency symbol 'PLN' or 'zł' is always present alongside numeric counters
        assert "PLN" in html or "zł" in html, "Currency units missing from UI ticker displays"

    def test_tier2_feat2_zero_savings_edge_case(self):
        """Verifies calculation with zero peak shaved returns zero contracted power savings."""
        from grid_optimizer import KrakowGridOptimizer
        opt = KrakowGridOptimizer(bess_capacity_mwh=4.0, bess_power_mw=0.0)
        df_dummy = pd.DataFrame({
            "Grid_Demand_MW": [2.0] * 96,
            "Net_Grid_Demand_MW": [2.0] * 96,
            "BESS_Discharge_MW": [0.0] * 96,
            "Tariff_PLN_MWh": [380.0] * 96
        })
        savings = opt.calculate_city_savings(df_dummy)
        assert savings["Contracted_Power_Savings_PLN_Year"] == 0.0

    def test_tier2_feat2_extreme_high_numeric_values(self):
        """Verifies optimizer calculation and financial scaling for 8-digit citywide scale (e.g. >10,000,000 PLN)."""
        import numpy as np
        from grid_optimizer import KrakowGridOptimizer
        opt_large = KrakowGridOptimizer(bess_capacity_mwh=50.0, bess_power_mw=25.0)
        df_large = pd.DataFrame({
            "Grid_Demand_MW": [45.0] * 96,
            "Net_Grid_Demand_MW": [30.0] * 96,
            "BESS_Discharge_MW": [15.0] * 96,
            "Tariff_PLN_MWh": [720.0] * 96
        })
        savings = opt_large.calculate_city_savings(df_large, capex_pln_per_mwh=950000.0)
        assert savings["Total_CAPEX_PLN"] == 47500000.0
        assert savings["Total_Annual_Savings_PLN"] > 10000000.0
        assert not np.isnan(savings["Total_Annual_Savings_PLN"])

    def test_tier2_feat2_nan_undefined_display_fallback(self):
        """Verifies that HTML markup contains no literal 'NaN', 'undefined', or 'null' placeholder text."""
        soup = get_scada_soup()
        # Check text in body
        body_text = soup.body.get_text() if soup.body else ""
        # Check for visible literal 'undefined' as standalone token
        assert not re.search(r'\bundefined\b', body_text), "Literal 'undefined' found rendered in document text"
        assert not re.search(r'\bNaN\b', body_text), "Literal 'NaN' found rendered in document text"

    def test_tier2_feat2_currency_string_locale_formatting(self):
        """Verifies numbers use Polish or international space-separated thousands."""
        html = get_scada_html()
        # Valid forms: 795 721 or 795,721 or 795721
        assert re.search(r'795[\s,.]?721', html) or "795" in html, "795k savings number format not recognized"

    # ---------------- Feature 3 Boundaries ----------------
    def test_tier2_feat3_extreme_coordinates_clamping(self):
        """Verifies all Krakow WebGIS hub coordinates lie within valid Krakow metropolitan bounding box."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        lats = [float(x) for x in re.findall(r'"lat":\s*([0-9.]+)', content)]
        lons = [float(x) for x in re.findall(r'"lon":\s*([0-9.]+)', content)]
        for lat in lats:
            assert 49.90 <= lat <= 50.25, f"Latitude {lat} outside Krakow region"
        for lon in lons:
            assert 19.75 <= lon <= 20.30, f"Longitude {lon} outside Krakow region"

    def test_tier2_feat3_zoom_limits_boundary(self):
        """Verifies map zoom limits are bounded (min zoom >= 0, max zoom <= 22)."""
        html = get_scada_html()
        # Look for zoom config in map init
        zoom_matches = re.findall(r'zoom:\s*([0-9.]+)', html)
        if zoom_matches:
            for z in zoom_matches:
                val = float(z)
                assert 0.0 <= val <= 22.0, f"Zoom value {val} out of expected bounds"

    def test_tier2_feat3_offline_canvas_fallback_when_webgl_disabled(self):
        """Verifies that offline fallback canvas or vector rendering logic exists for non-WebGL environments."""
        html = get_scada_html()
        # Either fallback canvas, local maplibre, or local tile cache logic must be present
        assert "canvas" in html.lower() or "maplibregl" in html or "offline" in html.lower(), \
            "No canvas or offline map fallback structure found"

    def test_tier2_feat3_zero_transit_routes_resilience(self):
        """Verifies dataset structure gracefully represents empty transit route groups."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert '"transit_routes"' in content

    def test_tier2_feat3_map_container_zero_dimension_resize(self):
        """Verifies map container has flex/absolute sizing preventing 0x0 rendering collapses."""
        soup = get_scada_soup()
        map_el = soup.find(id=re.compile(r"map", re.I))
        if map_el and map_el.has_attr("style"):
            style = map_el["style"]
            assert "0px" not in style or "height: 100%" in style or "width: 100%" in style

    # ---------------- Feature 4 Boundaries ----------------
    def test_tier2_feat4_charger_index_boundary_zero_and_fiftyone(self):
        """Verifies charger indices range from 1 to 52 (or 0 to 51) without overflow."""
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            kpi = json.load(f)
        assert kpi["EV_Chargers_Count"] == 52

    def test_tier2_feat4_charger_index_out_of_range_handling(self):
        """Verifies that requesting charger index > 52 does not return undefined station data."""
        # Check boundary condition in python data loader
        from data_loader import KrakowDataLoader
        loader = KrakowDataLoader()
        depots = loader.get_mpk_depots()
        depot = depots[depots["id"] == "DEP-01"].iloc[0]
        assert depot["chargers_kw"] > 0

    def test_tier2_feat4_zero_ev_buses_edge_condition(self):
        """Verifies decarbonization model calculates 0 avoided emissions when bus count is 0."""
        from decarbonization import KrakowDecarbonizationCalculator
        calc = KrakowDecarbonizationCalculator()
        res = calc.calculate_fleet_electrification_benefits(0)
        assert res["Net_CO2_Avoided_Tons"] == 0.0

    def test_tier2_feat4_max_fleet_capacity_121_buses(self):
        """Verifies decarbonization model handles full fleet of 121 electric buses."""
        from decarbonization import KrakowDecarbonizationCalculator
        calc = KrakowDecarbonizationCalculator()
        res = calc.calculate_fleet_electrification_benefits(121)
        assert res["Net_CO2_Avoided_Tons"] > 1000.0

    def test_tier2_feat4_depot_polygon_closure_validation(self):
        """Verifies depot coordinates contain at least 3 points forming a closed geometric polygon."""
        # Check if coordinates in dataset are valid pairs
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "50." in content and "19." in content

    # ---------------- Feature 5 Boundaries ----------------
    def test_tier2_feat5_scrubber_at_step_zero_midnight(self):
        """Verifies step 0 corresponds to midnight 00:00 with night tariff rate."""
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        row_0 = df.iloc[0]
        assert "00:00:00" in str(row_0["Datetime"])
        assert row_0["Taryfa_B23_PLN_MWh"] == 380.0

    def test_tier2_feat5_scrubber_at_step_ninetyfive_end_of_day(self):
        """Verifies step 95 corresponds to 23:45 end of daily cycle."""
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        row_95 = df.iloc[95]
        assert "23:45:00" in str(row_95["Datetime"])

    def test_tier2_feat5_scrubber_negative_step_clamping(self):
        """Verifies scrubber slider HTML attribute min is 0."""
        soup = get_scada_soup()
        slider = soup.find("input", {"type": "range"})
        if slider and slider.has_attr("min"):
            assert int(slider["min"]) == 0

    def test_tier2_feat5_scrubber_excessive_step_clamping(self):
        """Verifies scrubber slider HTML attribute max does not exceed 1440."""
        soup = get_scada_soup()
        slider = soup.find("input", {"type": "range"})
        if slider and slider.has_attr("max"):
            assert int(slider["max"]) <= 1440

    def test_tier2_feat5_rapid_scrubbing_event_stress(self):
        """Verifies timeseries lookup by index is sub-millisecond (resilient to 60 FPS scrubbing)."""
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        t0 = time.perf_counter()
        for idx in range(96):
            _ = df.iloc[idx]["Pobor_Zoptymalizowany_Siec_MW"]
        elapsed = time.perf_counter() - t0
        assert elapsed < 0.1, f"Timeseries access too slow for 60 FPS: {elapsed:.4f}s"

    # ---------------- Feature 6 Boundaries ----------------
    def test_tier2_feat6_battery_soc_exact_zero_percent(self):
        """Verifies battery model enforces minimum DOD limit (does not discharge below 0% or 10% reserve)."""
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        assert (df["Stan_Energii_BESS_MWh"] >= 0.0).all(), "Negative battery energy state detected"

    def test_tier2_feat6_battery_soc_exact_one_hundred_percent(self):
        """Verifies battery model never exceeds nominal 4.0 MWh capacity."""
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        assert (df["Stan_Energii_BESS_MWh"] <= 4.0 + 1e-3).all(), "Battery overcharged beyond 4.0 MWh"

    def test_tier2_feat6_battery_temperature_subzero_celsius(self):
        """Verifies degradation model can evaluate subzero ambient operating temperature."""
        from bess_degradation import KrakowBessDegradationModel
        model = KrakowBessDegradationModel("LFP")
        traj = model.simulate_degradation_trajectory(capacity_mwh=4.0, avg_cell_temp_c=-15.0)
        assert traj["SoH_After_10_Years_Percent"] > 60.0

    def test_tier2_feat6_battery_temperature_thermal_overheat(self):
        """Verifies degradation model simulates accelerated aging under 40°C heat wave conditions."""
        from bess_degradation import KrakowBessDegradationModel
        model = KrakowBessDegradationModel("LFP")
        traj_normal = model.simulate_degradation_trajectory(capacity_mwh=4.0, avg_cell_temp_c=25.0)
        traj_hot = model.simulate_degradation_trajectory(capacity_mwh=4.0, avg_cell_temp_c=40.0)
        assert traj_hot["SoH_After_15_Years_Percent"] <= traj_normal["SoH_After_15_Years_Percent"]

    def test_tier2_feat6_battery_degradation_beyond_fifteen_years(self):
        """Verifies degradation trajectory correctly spans 15 years."""
        from bess_degradation import KrakowBessDegradationModel
        model = KrakowBessDegradationModel("LFP")
        traj = model.simulate_degradation_trajectory(capacity_mwh=4.0, years=15)
        df_traj = traj["Trajectory_DataFrame"]
        assert len(df_traj) == 15
        assert df_traj.iloc[-1]["Year"] == 15

    # ---------------- Feature 7 Boundaries ----------------
    def test_tier2_feat7_unknown_scenario_id_fallback(self):
        """Verifies crisis simulator rejects or falls back gracefully on unknown scenario name."""
        from crisis_simulator import KrakowCrisisSimulator
        sim = KrakowCrisisSimulator()
        res = sim.simulate_crisis(pd.DataFrame({"Grid_Demand_MW": [3.0]}), "NON_EXISTENT_SCENARIO")
        assert res is not None and "Scenario_Name" in res

    def test_tier2_feat7_rapid_mode_switching_debounce(self):
        """Verifies multiple scenario runs execute in under 1 second."""
        from crisis_simulator import KrakowCrisisSimulator
        from data_loader import KrakowDataLoader
        loader = KrakowDataLoader()
        df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=1)
        sim = KrakowCrisisSimulator()
        t0 = time.perf_counter()
        sim.simulate_crisis(df_prof, "WINTER_FREEZE")
        sim.simulate_crisis(df_prof, "BLACKOUT_ISLAND")
        sim.simulate_crisis(df_prof, "DUNKELFLAUTE_PEAK")
        assert (time.perf_counter() - t0) < 1.0

    def test_tier2_feat7_blackout_with_depleted_battery_edge(self):
        """Verifies blackout islanding simulation with zero battery capacity raises warning or handles 0 hours."""
        from crisis_simulator import KrakowCrisisSimulator
        from data_loader import KrakowDataLoader
        loader = KrakowDataLoader()
        df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=1)
        sim = KrakowCrisisSimulator()
        res = sim.simulate_crisis(df_prof, "BLACKOUT_ISLAND", bess_cap_mwh=0.0, bess_power_mw=0.0)
        assert res["Island_Hours_Secured"] == 0.0

    def test_tier2_feat7_winter_freeze_load_exceeds_connection(self):
        """Verifies winter freeze scenario simulates heating demand jump above unmitigated baseline."""
        from crisis_simulator import KrakowCrisisSimulator
        from data_loader import KrakowDataLoader
        loader = KrakowDataLoader()
        df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=1)
        sim = KrakowCrisisSimulator()
        res = sim.simulate_crisis(df_prof, "WINTER_FREEZE")
        assert res["Raw_Crisis_Peak_MW"] > df_prof["Grid_Demand_MW"].max()

    def test_tier2_feat7_extreme_market_price_spike_4000pln(self):
        """Verifies Dunkelflaute scenario accurately computes penalty avoidance during market spike."""
        from crisis_simulator import KrakowCrisisSimulator
        from data_loader import KrakowDataLoader
        loader = KrakowDataLoader()
        df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=1)
        sim = KrakowCrisisSimulator()
        res = sim.simulate_crisis(df_prof, "DUNKELFLAUTE_PEAK")
        assert res["Penalties_Avoided_PLN"] > 0.0

    # ---------------- Feature 8 Boundaries ----------------
    def test_tier2_feat8_escape_key_closes_modal(self):
        """Verifies modal markup contains close button or escape handler."""
        html = get_scada_html()
        assert "close" in html.lower() or "zamknij" in html.lower() or "btn-close" in html.lower() or "modal" in html.lower(), \
            "No modal close mechanism declared"

    def test_tier2_feat8_backdrop_click_closes_modal(self):
        """Verifies modal structure has backdrop overlay element."""
        soup = get_scada_soup()
        overlay = soup.find(class_=re.compile(r"modal|overlay|backdrop", re.I)) or soup.find(id=re.compile(r"modal", re.I))
        assert overlay is not None or "modal" in get_scada_html().lower()

    def test_tier2_feat8_missing_asset_graceful_alert(self):
        """Verifies file existence check for required downloads."""
        assert os.path.exists(EXCEL_MODEL_PATH)
        assert os.path.exists(PDF_SUMMARY_PATH) or os.path.exists(PDF_CONTEST_PATH)

    def test_tier2_feat8_multiple_modal_opening_prevention(self):
        """Verifies modal z-index or stacking prevents UI collision."""
        html = get_scada_html()
        assert "z-index" in html or "modal" in html

    def test_tier2_feat8_modal_accessibility_aria_attributes(self):
        """Verifies semantic HTML or accessible roles in modal markup."""
        html = get_scada_html()
        assert "role=" in html or "aria-" in html or "<dialog" in html or "class=" in html

    # ---------------- Feature 9 Boundaries ----------------
    def test_tier2_feat9_airgap_offline_provenance_state(self):
        """Verifies application contains fallback data strings when operating completely offline."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "Kraków" in content
        assert "Wola Duchacka" in content

    def test_tier2_feat9_invalid_url_sanitization(self):
        """Verifies provenance URLs in code strictly use HTTPS."""
        html = get_scada_html()
        http_insecure_links = re.findall(r'href=["\']http://(?!localhost|127\.0\.0\.1)[^"\']+["\']', html)
        assert len(http_insecure_links) == 0, f"Insecure HTTP links detected: {http_insecure_links}"

    def test_tier2_feat9_xss_prevention_in_metadata_tags(self):
        """Verifies no script injection payloads exist in metadata descriptions."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "<script>" not in content
        assert "javascript:" not in content

    def test_tier2_feat9_missing_provenance_attribute_fallback(self):
        """Verifies dataset metadata object includes valid title and CRS attribution."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "EPSG:4326" in content or "WGS84" in content

    def test_tier2_feat9_provenance_https_link_integrity(self):
        """Verifies official portal URLs are correctly formatted."""
        html = get_scada_html()
        if "otwartedane.um.krakow.pl" in html:
            assert "https://otwartedane.um.krakow.pl" in html or "otwartedane.um.krakow.pl" in html

    # ---------------- Feature 10 Boundaries ----------------
    def test_tier2_feat10_server_port_collision_fallback(self):
        """Verifies server.py create_server function attempts next ports on collision."""
        from server import create_server
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('127.0.0.1', 8989))
        s.listen(1)
        try:
            httpd, p = create_server(8989)
            assert p > 8989, f"Port fallback failed to increment (p={p})"
            httpd.server_close()
        finally:
            s.close()

    def test_tier2_feat10_server_404_on_nonexistent_path(self, live_server):
        """Verifies server returns 404 for nonexistent path."""
        url = f"{live_server}/non_existent_file_9999.xyz"
        try:
            req = urllib.request.urlopen(url)
            assert False, "Expected HTTP 404 error"
        except urllib.error.HTTPError as e:
            assert e.code == 404

    def test_tier2_feat10_server_directory_traversal_protection(self, live_server):
        """Verifies server blocks directory traversal attacks (../)."""
        url = f"{live_server}/../../../../Windows/win.ini"
        try:
            urllib.request.urlopen(url)
        except urllib.error.HTTPError as e:
            assert e.code in [400, 403, 404]

    def test_tier2_feat10_server_head_method_support(self, live_server):
        """Verifies server supports HEAD requests with appropriate Content-Length."""
        req = urllib.request.Request(f"{live_server}/data/wola_duchacka_kpi_summary.json", method="HEAD")
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 200
            assert "Content-Length" in resp.headers

    def test_tier2_feat10_server_large_binary_streaming(self, live_server):
        """Verifies server streams large Excel or PDF binary files completely."""
        url = f"{live_server}/0_DLA_CIEBIE_I_JURY/02_MODEL_FINANSOWY_EXCEL.xlsx"
        with urllib.request.urlopen(url) as resp:
            assert resp.status == 200
            data = resp.read()
            assert len(data) > 10000, "Downloaded Excel binary corrupted or truncated"


# ==============================================================================
# TIER 3: CROSS-FEATURE COMBINATIONS (10 Interaction Tests)
# ==============================================================================

class TestTier3CrossFeatureCombinations:
    """Tier 3: Pairwise and multi-way feature interactions."""

    def test_tier3_scrubbing_during_winter_freeze_scenario(self):
        """Interacts timeline scrubbing with active Winter Freeze scenario demand calculations."""
        from crisis_simulator import KrakowCrisisSimulator
        from data_loader import KrakowDataLoader
        loader = KrakowDataLoader()
        df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=1)
        sim = KrakowCrisisSimulator()
        res = sim.simulate_crisis(df_prof, "WINTER_FREEZE")
        # Ensure peak remains mitigated while scrubbing through 24h profile
        assert res["Mitigated_Peak_MW"] < res["Raw_Crisis_Peak_MW"]
        assert res["Raw_Crisis_Peak_MW"] > df_prof["Grid_Demand_MW"].max()
        assert res["Penalties_Avoided_PLN"] > 0

    def test_tier3_modal_open_during_vehicle_animation(self):
        """Verifies DOM elements for both modal dialog and map transit layer coexist without hierarchy conflict."""
        soup = get_scada_soup()
        map_el = soup.find(id=re.compile(r"map|webgl", re.I))
        assert map_el is not None
        # Verify page can contain both map and modal/panel
        assert len(soup.find_all(["div", "section"])) >= 5

    def test_tier3_offline_canvas_fallback_with_gtfs_rendering(self):
        """Verifies GTFS route coordinate arrays can be iterated for 2D canvas drawing."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        # Find coordinates list in transit routes
        coords_match = re.search(r'"coordinates":\s*(\[\[[0-9.,\s\-\[\]]+\]\])', content)
        assert coords_match is not None, "Transit route coordinates missing for canvas renderer"

    def test_tier3_scenario_switch_updates_battery_hud_telemetry(self):
        """Verifies Blackout Islanding mode alters battery discharge power."""
        from crisis_simulator import KrakowCrisisSimulator
        from data_loader import KrakowDataLoader
        loader = KrakowDataLoader()
        df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=1)
        sim = KrakowCrisisSimulator()
        res_normal = sim.simulate_crisis(df_prof, "WINTER_FREEZE")
        res_blackout = sim.simulate_crisis(df_prof, "BLACKOUT_ISLAND", bess_cap_mwh=4.0, bess_power_mw=2.0)
        assert res_blackout["Island_Hours_Secured"] >= 1.0

    def test_tier3_provenance_modal_interaction_with_excel_modal(self):
        """Verifies both provenance metadata and Excel download links are simultaneously accessible."""
        html = get_scada_html()
        assert "otwartedane" in html or "msip" in html or "ztp" in html or "umk" in html.lower()
        assert "excel" in html.lower() or ".xlsx" in html

    def test_tier3_scrubber_syncs_curve_and_battery_dial(self):
        """Verifies each timeseries step contains both grid load and battery SOC for synchronized UI update."""
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        for _, row in df.head(10).iterrows():
            grid = row["Pobor_Zoptymalizowany_Siec_MW"]
            soc = row["Stan_Energii_BESS_MWh"]
            assert grid >= 0.0 and soc >= 0.0

    def test_tier3_wola_duchacka_microgis_sync_with_timeline(self):
        """Verifies high-zoom Wola Duchacka coordinates correlate with timeseries depot load."""
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            kpi = json.load(f)
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        assert abs(df["Pobor_Niezarzadzany_MW"].max() - kpi["Unmanaged_Peak_Load_MW"]) < 0.2

    def test_tier3_blackout_scenario_isolates_grid_feeders_and_updates_ticker(self):
        """Verifies blackout mode forces net grid demand to 0 MW while supplying depot from BESS."""
        from crisis_simulator import KrakowCrisisSimulator
        from data_loader import KrakowDataLoader
        loader = KrakowDataLoader()
        df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=1)
        sim = KrakowCrisisSimulator()
        res = sim.simulate_crisis(df_prof, "BLACKOUT_ISLAND", bess_cap_mwh=4.0, bess_power_mw=2.0)
        assert res["Mitigated_Peak_MW"] == 0.0

    def test_tier3_layer_visibility_persistence_across_scenarios(self):
        """Verifies WebGIS layers config includes togglable layer types (hubs, gpz, grid, transit)."""
        with open(WEBGIS_DATA_PATH, "r", encoding="utf-8") as f:
            content = f.read()
        assert "hubs" in content and "gpzs" in content and "grid_lines" in content

    def test_tier3_excel_download_during_scrubber_drag(self, live_server):
        """Verifies downloading the Excel model does not interrupt HTTP server responsiveness."""
        url = f"{live_server}/0_DLA_CIEBIE_I_JURY/02_MODEL_FINANSOWY_EXCEL.xlsx"
        req = urllib.request.urlopen(url)
        assert req.status == 200
        # Immediately query JSON endpoint to confirm zero server blocking
        req2 = urllib.request.urlopen(f"{live_server}/data/wola_duchacka_kpi_summary.json")
        assert req2.status == 200


# ==============================================================================
# TIER 4: REAL-WORLD APPLICATION SCENARIOS (4 End-to-End Scenarios)
# ==============================================================================

class TestTier4RealWorldScenarios:
    """Tier 4: Comprehensive end-to-end operational workflows and compliance validations."""

    def test_tier4_jury_walkthrough_lifecycle(self, live_server):
        """
        Scenario 1: UMK Jury Walkthrough Simulation:
        1. Access landing page via HTTP server.
        2. Verify 200 OK status and correct MIME type.
        3. Check page title for 'Kraków SmartGrid'.
        4. Validate presence of 5 core KPI indicators.
        5. Verify presence of Excel model launcher and PDF summary download.
        6. Confirm zero broken internal asset links.
        """
        # Fetch root or index.html
        req = urllib.request.urlopen(f"{live_server}/")
        assert req.status == 200
        content = req.read().decode("utf-8", errors="ignore")
        assert "kraków" in content.lower()
        # Verify Excel model asset reachable
        excel_req = urllib.request.urlopen(f"{live_server}/0_DLA_CIEBIE_I_JURY/02_MODEL_FINANSOWY_EXCEL.xlsx")
        assert excel_req.status == 200
        # Verify PDF technical doc asset reachable
        pdf_req = urllib.request.urlopen(f"{live_server}/0_DLA_CIEBIE_I_JURY/03_DOKUMENTACJA_TECHNICZNA.pdf")
        assert pdf_req.status == 200

    def test_tier4_full_24h_wola_duchacka_dispatch_cycle(self):
        """
        Scenario 2: Full 24-Hour Wola Duchacka Dispatch Simulation:
        - 96 consecutive 15-minute intervals.
        - Night charging (01:00-05:00) in cheap B23 valley (380 PLN/MWh).
        - Morning fleet departure (05:00-08:00) with low depot demand.
        - Evening peak arrival (21:00-23:30) reaching 5.04 MW.
        - BESS discharge (1.37 MW) capping grid import at 3.67 MW.
        - Conservation of energy across all intervals.
        """
        df = pd.read_csv(TIMESERIES_CSV_PATH)
        assert len(df) >= 96
        # Verify peak shaving occurred
        unmanaged_max = df["Pobor_Niezarzadzany_MW"].max()
        managed_max = df["Pobor_Zoptymalizowany_Siec_MW"].max()
        assert unmanaged_max >= 4.8, f"Unmanaged peak too low: {unmanaged_max}"
        assert managed_max <= 3.8, f"Managed peak too high: {managed_max}"
        assert (unmanaged_max - managed_max) >= 1.0, "Peak reduction less than 1.0 MW"

    def test_tier4_blackout_microgrid_islanding_4_8h(self):
        """
        Scenario 3: 4.8h Blackout Microgrid Isolation Resilience:
        - Simulates loss of 110/15 kV GPZ Podgórze.
        - BESS 4.0 MWh / 2.0 MW enters islanded microgrid mode.
        - Sustains emergency fleet charging and TETRA comms for >= 4.5 hours (under critical load) or >= 1.5h (unthrottled).
        - Avoids municipal grid failure penalties.
        """
        from crisis_simulator import KrakowCrisisSimulator
        from data_loader import KrakowDataLoader
        loader = KrakowDataLoader()
        df_prof = loader.generate_synthetic_hourly_profile("DEP-01", days=1)
        sim = KrakowCrisisSimulator()
        res = sim.simulate_crisis(df_prof, "BLACKOUT_ISLAND", bess_cap_mwh=4.0, bess_power_mw=2.0)
        assert res["Island_Hours_Secured"] >= 1.5, f"Secured hours {res['Island_Hours_Secured']} below 1.5h unthrottled baseline"
        assert res["Penalties_Avoided_PLN"] > 100000.0, "Penalty avoidance below threshold"

    def test_tier4_financial_reconciliation_vs_official_excel(self):
        """
        Scenario 4: Penny-Accurate Financial Reconciliation:
        Reconciles web KPIs, JSON data, and official Excel spreadsheet:
        - Filar 1 (Moc zamówiona Tauron B23): 345 370.39 PLN
        - Filar 2 (Opłata mocowa URE 21:00-22:00): 147 809.02 PLN
        - Filar 3 (Arbitraż nocny B23): 302 541.66 PLN
        - Łączne roczne oszczędności: 795 721.07 PLN
        - Nakłady inwestycyjne (CAPEX): 3 800 000 PLN
        - Dotacja 70% (FEnIKS / KPO): 2 660 000 PLN
        - Wkład własny miasta (Equity): 1 140 000 PLN
        - Prosty czas zwrotu wkładu własnego: 1.4 roku (~17 miesięcy).
        """
        # 1. Read JSON
        with open(KPI_JSON_PATH, "r", encoding="utf-8") as f:
            kpi = json.load(f)
        assert abs(kpi["Total_Annual_Savings_PLN"] - 795721.07) < 1.0
        assert abs(kpi["Annual_Contracted_Power_Savings_PLN"] - 345370.39) < 1.0
        assert abs(kpi["Annual_Capacity_Fee_Savings_PLN"] - 147809.02) < 1.0
        assert abs(kpi["Annual_Tariff_Arbitrage_Savings_PLN"] - 302541.66) < 1.0
        assert abs(kpi["Total_CAPEX_PLN"] - 3800000.0) < 1.0
        assert abs(kpi["Municipal_Equity_PLN"] - 1140000.0) < 1.0
        assert abs(kpi["Simple_Payback_Subsidized_Years"] - 1.4) < 0.1

        # 2. Read Excel Workbook & Evaluate Formulas Mathematically
        wb = openpyxl.load_workbook(EXCEL_MODEL_PATH, data_only=False)
        ws_sav = wb["Kalkulacja_Oszczednosci"]
        ws_prof = wb["Profil_Mocy_24h_15min"]
        ws_assump = wb["Zalozenia_i_Zrodla"]

        # Assert all cells contain active dynamic formulas (no hardcoded literal floats)
        assert str(ws_sav["E11"].value).startswith("="), f"E11 must be formula, got {ws_sav['E11'].value}"
        assert str(ws_sav["E18"].value).startswith("="), f"E18 must be formula, got {ws_sav['E18'].value}"
        assert str(ws_sav["E25"].value).startswith("="), f"E25 must be formula, got {ws_sav['E25'].value}"
        assert ws_sav["E27"].value == "=E11+E18+E25", f"E27 must sum the 3 pillars, got {ws_sav['E27'].value}"

        # Evaluate Sheet 2 (Profil_Mocy_24h_15min)
        e_vals = [ws_prof.cell(row=r, column=5).value for r in range(4, 100)]
        f_vals = [ws_prof.cell(row=r, column=6).value for r in range(4, 100)]
        g_vals = [e_vals[i] - f_vals[i] for i in range(len(e_vals))]
        
        max_raw_mw = max(e_vals)
        max_net_mw = max(g_vals)
        assert round(max_raw_mw, 2) == 5.04, f"Sheet 2 peak must be 5.04 MW, got {max_raw_mw}"
        assert round(max_net_mw, 2) == 3.67, f"Sheet 2 managed peak must be 3.67 MW, got {max_net_mw}"

        # Evaluate Sheet 3 Pillar 1 (E11: =C8*C9*12*C10)
        c8_delta_kw = (max_raw_mw - max_net_mw) * 1000.0
        c9_rate = ws_assump["C16"].value
        c10_avail = ws_assump["C28"].value
        val_e11 = c8_delta_kw * c9_rate * 12.0 * c10_avail

        # Evaluate Sheet 3 Pillar 2 (E18: =C16*C17)
        c14_day = ws_sav["C14"].value
        c15_days = ws_sav["C15"].value
        c16_year = c14_day * c15_days
        c17_ure_rate = ws_assump["C20"].value
        val_e18 = c16_year * c17_ure_rate

        # Evaluate Sheet 3 Pillar 3 (E25: =C21*C24)
        c21_volume = ws_sav["C21"].value
        c22_noc = ws_assump["C18"].value
        c23_dzien = ws_assump["C19"].value
        rte = ws_assump["C12"].value
        c24_spread = c23_dzien - (c22_noc / rte)
        val_e25 = c21_volume * c24_spread

        # Evaluate Sheet 3 Total (E27: =E11+E18+E25)
        val_e27 = val_e11 + val_e18 + val_e25

        assert abs(val_e11 - 345370.39) < 0.1, f"Filar 1 must evaluate to 345 370.39 PLN, got {val_e11}"
        assert abs(val_e18 - 147809.02) < 0.1, f"Filar 2 must evaluate to 147 809.02 PLN, got {val_e18}"
        assert abs(val_e25 - 302541.66) < 0.1, f"Filar 3 must evaluate to 302 541.66 PLN, got {val_e25}"
        assert abs(val_e27 - 795721.07) < 0.1, f"Total E27 must evaluate to 795 721.07 PLN, got {val_e27}"

        # 3. Read PDF 2-page formal document
        pdf_reader = pypdf.PdfReader(PDF_SUMMARY_PATH)
        assert len(pdf_reader.pages) == 2, f"PDF strictly required to be exactly 2 pages, got {len(pdf_reader.pages)}"
        pdf_text = "".join([page.extract_text() or "" for page in pdf_reader.pages])
        assert "795" in pdf_text and "721" in pdf_text, "795 721 PLN savings not cited in official 2-page PDF"
        assert "1,14" in pdf_text or "1.14" in pdf_text, "1.14M PLN equity not cited in official 2-page PDF"
        assert "1,4" in pdf_text or "1.4" in pdf_text, "1.4 year payback not cited in official 2-page PDF"

    def test_tier4_presentation_and_tutorial_assets(self):
        """Verifies presence, integrity and link resolution of the theoretical presentation and tutorial masterclass."""
        pres_root = os.path.join(ROOT_DIR, "prezentacja_teoria_i_tutorial.html")
        if not os.path.exists(pres_root):
            pres_root = os.path.join(ROOT_DIR, "_archiwum_robocze", "stare_prezentacje_i_wideo", "prezentacja_teoria_i_tutorial.html")
        pres_jury = os.path.join(ROOT_DIR, "0_DLA_CIEBIE_I_JURY", "10_PREZENTACJA_TEORIA_I_TUTORIAL.html")
        if not os.path.exists(pres_jury):
            pres_jury = os.path.join(ROOT_DIR, "_archiwum_robocze", "stare_prezentacje_i_wideo", "10_PREZENTACJA_TEORIA_I_TUTORIAL.html")
        bat_jury = os.path.join(ROOT_DIR, "0_DLA_CIEBIE_I_JURY", "12_URUCHOM_PREZENTACJE_I_TUTORIAL.bat")
        if not os.path.exists(bat_jury):
            bat_jury = os.path.join(ROOT_DIR, "_archiwum_robocze", "stare_prezentacje_i_wideo", "12_URUCHOM_PREZENTACJE_I_TUTORIAL.bat")
        manifest_path = os.path.join(ROOT_DIR, "data", "audio_presentation", "audio_manifest.json")
        video_mp4 = os.path.join(ROOT_DIR, "0_DLA_CIEBIE_I_JURY", "Krakow_SmartGrid_Video_Walkthrough_SCADA.mp4")
        if not os.path.exists(video_mp4):
            video_mp4 = os.path.join(ROOT_DIR, "_archiwum_robocze", "stare_prezentacje_i_wideo", "Krakow_SmartGrid_Video_Walkthrough_SCADA.mp4")

        assert os.path.exists(pres_root), f"Missing {pres_root}"
        assert os.path.exists(pres_jury), f"Missing {pres_jury}"
        assert os.path.exists(bat_jury), f"Missing {bat_jury}"
        assert os.path.exists(manifest_path), f"Missing {manifest_path}"
        assert os.path.exists(video_mp4), f"Missing {video_mp4}"

        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = json.load(f)
        assert len(manifest["chapters"]) == 10, f"Expected exactly 10 chapters, got {len(manifest['chapters'])}"
        assert manifest["total_duration"] > 480.0, f"Expected total duration > 480s, got {manifest['total_duration']}"

        # Verify each chapter audio file exists
        audio_dir = os.path.join(ROOT_DIR, "data", "audio_presentation")
        for ch in manifest["chapters"]:
            ch_mp3 = os.path.join(audio_dir, ch["filename"])
            assert os.path.exists(ch_mp3), f"Missing audio chapter file: {ch_mp3}"

        # Verify zero broken links in active presentations
        import re
        for full_file in [pres_root, pres_jury]:
            if "_archiwum_robocze" in full_file:
                continue
            file_dir = os.path.dirname(full_file)
            with open(full_file, "r", encoding="utf-8") as f:
                html = f.read()
            
            assert "795 721" in html
            assert "Tauron B23" in html
            assert "Behind-the-Meter" in html

            links = re.findall(r'(?:href|src)=[\'"]([^\'"]+)[\'"]', html)
            audio_files = re.findall(r'file:\s*[\'"]([^\'"]+)[\'"]', html)
            poster_files = re.findall(r'poster=[\'"]([^\'"]+)[\'"]', html)
            all_refs = set(links + audio_files + poster_files)

            for ref in all_refs:
                if ref.startswith("#") or ref.startswith("http") or ref.startswith("javascript"):
                    continue
                clean = ref.split("?")[0].split("#")[0]
                loc_file = os.path.normpath(os.path.join(file_dir, clean))
                assert os.path.exists(loc_file), f"Broken reference '{ref}' in {full_file} (resolved to {loc_file})"

    def test_server_page_argument_and_dispatch(self):
        """Verifies server.py argument parsing for --page and default fallbacks."""
        import subprocess
        cmd = [sys.executable, "-c", "import server; assert hasattr(server, 'start_server')"]
        res = subprocess.run(cmd, cwd=ROOT_DIR, capture_output=True, text=True)
        assert res.returncode == 0, f"server.py import error: {res.stderr}"


class TestScadaSingleLineDiagramAndExecutiveCockpit:
    """Rigorous verification suite for Single-Line Diagram (SLD), Executive Cockpit, and Open Data Inspector."""

    def test_sld_vector_svg_architecture_and_components(self):
        """Verifies presence of SLD view container, SVG schematic, GPZ Kurdwanów, BESS, and 117 charging bays."""
        soup = get_scada_soup()
        sld_view = soup.find(id="sld-view")
        assert sld_view is not None, "Missing #sld-view container in SCADA interface"

        svg_canvas = sld_view.find("svg", class_="sld-svg-canvas")
        assert svg_canvas is not None, "Missing .sld-svg-canvas element"

        svg_text = svg_canvas.get_text()
        svg_upper = svg_text.upper()
        assert "GPZ KURDWANÓW" in svg_upper or "110/15 KV" in svg_upper
        assert "15 KV" in svg_upper
        assert "PCS 2.0 MW" in svg_upper
        assert "4.0 MWH" in svg_upper or "BESS" in svg_upper
        assert "117 STANOWISK" in svg_upper or "16 PANTOGRAFÓW" in svg_upper
        assert "101 STANOWISK CCS2" in svg_upper or "CCS2" in svg_upper
        assert "121 E-BUSÓW" in svg_upper or "121" in svg_upper

        # Breakers Q1, Q2, Q3
        assert sld_view.find(id="sld-q1-rect") is not None, "Missing breaker Q1"
        assert sld_view.find(id="sld-q2-rect") is not None, "Missing breaker Q2"
        assert sld_view.find(id="sld-q3-rect") is not None, "Missing breaker Q3"

    def test_executive_cockpit_kpis_and_dcf_table(self):
        """Verifies Executive Cockpit elements: 4 KPI cards, 24h load chart, 3 savings pillars, and DCF 15Y table."""
        soup = get_scada_soup()
        cockpit = soup.find(id="cockpit-view")
        assert cockpit is not None, "Missing #cockpit-view in SCADA interface"

        text = cockpit.get_text()
        # 4 KPI indicators
        assert "795 721" in text, "Missing annual savings 795 721 zł in Cockpit"
        assert "1.4" in text or "17 m-cy" in text, "Missing payback SPB 1.4y indicator in Cockpit"
        assert "8.84" in text, "Missing 15-year net profit indicator in Cockpit"
        assert "1.37" in text, "Missing peak shaving -1.37 MW indicator in Cockpit"

        # 3 Pillars
        assert "Filar 1" in text and "345 370" in text, "Missing Filar 1 in Cockpit"
        assert "Filar 2" in text and "147 809" in text, "Missing Filar 2 in Cockpit"
        assert "Filar 3" in text and "302 542" in text, "Missing Filar 3 in Cockpit"

        # DCF 15-Year Table
        assert "DCF" in text or "Zdyskontowanych" in text
        assert "3 800 000" in text, "Missing CAPEX in DCF table"
        assert "1 140 000" in text, "Missing municipal equity in DCF table"
        assert "81.27%" in text, "Missing battery SOH 15Y in Cockpit"

    def test_audited_open_data_inspector_4_tabs(self):
        """Verifies 4-tab Audited Open Data Inspector modal, GTFS 670 arrivals, UMK registered vehicles, MSIP, PSE."""
        soup = get_scada_soup()
        modal = soup.find(id="provenance-modal")
        assert modal is not None, "Missing #provenance-modal inspector"

        # Tab buttons
        tab_btns = modal.find_all("button", class_=re.compile(r"open-data-tab-btn", re.I))
        assert len(tab_btns) >= 4, f"Expected 4 tab buttons in inspector, found {len(tab_btns)}"

        # Tab 1: GTFS
        tab1 = modal.find(id="od-tab-content-1")
        assert tab1 is not None, "Missing #od-tab-content-1 (GTFS)"
        t1_text = tab1.get_text()
        assert "670" in t1_text, "Missing 670 evening arrivals in Tab 1"
        assert "54" in t1_text and "21:30" in t1_text, "Missing peak 54 arrivals at 21:30 in Tab 1"
        assert "179" in t1_text and "174" in t1_text and "164" in t1_text, "Missing bus lines in Tab 1"

        # Tab 2: UMK Registered Vehicles
        tab2 = modal.find(id="od-tab-content-2")
        assert tab2 is not None, "Missing #od-tab-content-2 (UMK Vehicles)"
        t2_text = tab2.get_text()
        assert "1 626" in t2_text or "1626" in t2_text, "Missing 1626 buses in Tab 2"
        assert "api.um.krakow.pl" in t2_text, "Missing UMK API URL in Tab 2"

        # Tab 3: MSIP Kraków
        tab3 = modal.find(id="od-tab-content-3")
        assert tab3 is not None, "Missing #od-tab-content-3 (MSIP)"
        t3_text = tab3.get_text()
        assert "msip.krakow.pl" in t3_text or "Walerego Sławka" in t3_text

        # Tab 4: PSE e-SI / URE
        tab4 = modal.find(id="od-tab-content-4")
        assert tab4 is not None, "Missing #od-tab-content-4 (PSE / URE)"
        t4_text = tab4.get_text()
        assert "219.40" in t4_text or "B23" in t4_text or "43g" in t4_text

    def test_scada_mode_bar_and_slider_binding(self):
        """Verifies SCADA mode tabs and 24h timeline scrubber slider."""
        html = get_scada_html()
        assert "switchCentralMode" in html, "Missing switchCentralMode function in script"
        assert "switchOpenDataTab" in html, "Missing switchOpenDataTab function in script"
        assert "updateSLD" in html, "Missing updateSLD function in script"
        assert "updateExecutiveCockpit" in html, "Missing updateExecutiveCockpit function in script"

        soup = get_scada_soup()
        assert soup.find(id="tab-btn-sld") is not None, "Missing #tab-btn-sld"
        assert soup.find(id="tab-btn-cockpit") is not None, "Missing #tab-btn-cockpit"
        assert soup.find(id="timeline-slider") is not None, "Missing #timeline-slider"

    def test_server_canonical_jury_endpoints_no_404(self, live_server):
        """Verifies HTTP GET requests to canonical jury endpoints return HTTP 200."""
        endpoints = [
            "/0_DLA_CIEBIE_I_JURY/01_OPIS_PROJEKTU_2_STRONY_UMK.pdf",
            "/0_DLA_CIEBIE_I_JURY/02_MODEL_FINANSOWY_EXCEL.xlsx",
            "/0_DLA_CIEBIE_I_JURY/03_DOKUMENTACJA_TECHNICZNA.pdf",
            "/0_DLA_CIEBIE_I_JURY/Krakow_SmartGrid_Zgloszenie_Konkursowe.zip",
            "/krakow_smartgrid_scada.html"
        ]
        for ep in endpoints:
            url = f"{live_server}{ep}"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req) as resp:
                assert resp.status == 200, f"Endpoint {ep} returned {resp.status}"
                content = resp.read()
                assert len(content) > 1000, f"Endpoint {ep} returned too small payload ({len(content)} bytes)"

