"""
Krakow EcoGrid: Model Degradacji Elektrochemicznej i Cyklu Życia BESS (LFP vs NMC)
Numeryczny model starzenia kalendarzowego i cyklicznego wielkoskalowych magazynów energii.
Pozwala ocenić żywotność baterii w krakowskich węzłach MPK na przestrzeni 15 lat,
wyznaczyć wskaźnik SoH (State of Health), moment wymiany ogniw (EOL = 80%) oraz LCOS (Levelized Cost of Storage).
"""

import numpy as np
import pandas as pd


class KrakowBessDegradationModel:
    """
    Model degradacji baterii BESS oparty na semi-empirycznym prawie potęgowym zużycia cyklicznego
    (zależność od DoD i liczby cykli) oraz zlinearyzowanym współczynniku wrażliwości temperaturowej
    (zgodnie z modelami inżynierskimi Ecker et al. 2014, Schmalstieg et al. 2014).
    
    Porównanie technologii:
    1. LFP (Litowo-Żelazowo-Fosforanowe) - rekomendowane dla EcoGrid (wysokie bezpieczeństwo termiczne, 6000+ cykli).
    2. NMC (Niklowo-Manganowo-Kobaltowe) - wysoka gęstość energii, lecz szybsze starzenie (~3000 cykli).
    """

    CHEMISTRY_PARAMS = {
        "LFP": {
            "name": "Litowo-Żelazowo-Fosforanowe (LiFePO4)",
            "nominal_cycles_80_dod": 6000,
            "cal_k": 0.012,       # ~1.2% kalendarzowo rocznie w 20°C
            "cyc_k": 0.000123,    # Skalibrowane do 6000 cykli przy 80% DoD do EOL (80% SoH)
            "z_power": 0.82,      # wykładnik potęgowy zużycia cyklicznego
            "dod_exp": 1.45,      # wpływ głębokości rozładowania
            "temp_sens": 0.025,   # wrażliwość termiczna
            "thermal_runaway_temp_c": 270,
            "capex_per_kwh_pln": 950.0,
            "round_trip_eff": 0.88
        },
        "NMC": {
            "name": "Niklowo-Manganowo-Kobaltowe (NMC 811)",
            "nominal_cycles_80_dod": 3000,
            "cal_k": 0.022,       # ~2.2% kalendarzowo rocznie w 20°C
            "cyc_k": 0.000210,    # Skalibrowane do 3000 cykli przy 80% DoD do EOL (80% SoH)
            "z_power": 0.88,
            "dod_exp": 1.75,
            "temp_sens": 0.040,
            "thermal_runaway_temp_c": 210,
            "capex_per_kwh_pln": 1150.0,
            "round_trip_eff": 0.91
        }
    }

    def __init__(self, chemistry: str = "LFP"):
        if chemistry.upper() not in self.CHEMISTRY_PARAMS:
            chemistry = "LFP"
        self.chemistry = chemistry.upper()
        self.params = self.CHEMISTRY_PARAMS[self.chemistry]

    def simulate_degradation_trajectory(
        self,
        capacity_mwh: float = 6.0,
        cycles_per_day: float = 1.1,
        avg_dod: float = 0.75,
        avg_cell_temp_c: float = 22.0,
        years: int = 15,
        discount_rate: float = 0.05
    ) -> dict:
        """
        Symuluje trajektorię degradacji SoH (State of Health) na przestrzeni 15 lat.
        Wyznacza rok osiągnięcia End of Life (SoH <= 80%) oraz kalkuluje LCOS (PLN/MWh).
        """
        records = []
        soh = 1.0
        eol_year = None
        cumulative_mwh_throughput = 0.0
        p = self.params

        # Termika ogniwa (semi-empiryczny model wrażliwości temperaturowej):
        # Referencyjny punkt pracy: T_ref = 20°C (optymalne warunki pracy klimatyzacji kontenerowej HVAC).
        # Model stosuje inżynierski zlinearyzowany współczynnik wrażliwości temp_sens (np. 0.025 dla LFP = 2.5%/°C powyżej 20°C)
        # odzwierciedlający przyspieszone starzenie chemiczne i rozrost warstwy SEI (zgodnie z Ecker et al. 2014),
        # bez udawania rozwiązywania nieliniowych równań różniczkowych kinetyki Arrheniusa.
        # W temperaturach poniżej 20°C uwzględniono spadek kinetyki interkalacji i podwyższone
        # opory dyfuzyjne (współczynnik 0.75 * temp_sens).
        if avg_cell_temp_c >= 20.0:
            temp_factor = 1.0 + p["temp_sens"] * (avg_cell_temp_c - 20.0)
        else:
            temp_factor = 1.0 + (p["temp_sens"] * 0.75) * (20.0 - avg_cell_temp_c)

        dod_factor = (avg_dod / 0.80) ** p["dod_exp"]

        annual_cycles = cycles_per_day * 365.0
        annual_energy_per_year = capacity_mwh * avg_dod * annual_cycles * p["round_trip_eff"]

        # Narzut klimatyzacji kontenerowej HVAC (liquid cooling/heating)
        # 2.5% poboru bazowego + 0.1% za każdy stopień odchylenia od optimum 20°C
        hvac_parasitic_ratio = 0.025 + 0.001 * abs(avg_cell_temp_c - 20.0)

        discounted_energy_sum = 0.0
        discounted_opex_sum = 0.0
        capex_total = capacity_mwh * 1000.0 * p["capex_per_kwh_pln"]
        annual_opex = capex_total * 0.015  # 1.5% CAPEX na serwis i ubezpieczenie

        for year in range(1, years + 1):
            total_cycles = annual_cycles * year
            # Starzenie kalendarzowe (funkcja pierwiastkowa z czasu)
            deg_cal = p["cal_k"] * np.sqrt(year) * temp_factor
            # Starzenie cykliczne
            deg_cyc = p["cyc_k"] * (total_cycles ** p["z_power"]) * dod_factor * temp_factor

            total_deg = deg_cal + deg_cyc
            current_soh = max(0.50, 1.0 - total_deg)
            available_cap_mwh = capacity_mwh * current_soh

            if current_soh <= 0.80 and eol_year is None:
                eol_year = year

            cumulative_mwh_throughput += annual_energy_per_year * current_soh
            
            # Wartości zdyskontowane do LCOS
            dfactor = (1.0 + discount_rate) ** year
            discounted_energy_sum += (annual_energy_per_year * current_soh) / dfactor
            discounted_opex_sum += annual_opex / dfactor

            records.append({
                "Year": year,
                "SoH_Percent": round(float(current_soh * 100.0), 2),
                "Available_Capacity_MWh": round(float(available_cap_mwh), 2),
                "Capacity_Retention_Ratio": round(float(current_soh), 3),
                "Cumulative_Throughput_MWh": round(float(cumulative_mwh_throughput), 1),
                "Is_EOL_Reached": current_soh <= 0.80
            })

        df_trajectory = pd.DataFrame(records)

        # LCOS = (CAPEX + Sum(OPEX zdyskontowane)) / Sum(Energia dostarczona zdyskontowana)
        lcos_pln_mwh = (capex_total + discounted_opex_sum) / max(1.0, discounted_energy_sum)

        return {
            "Chemistry": self.chemistry,
            "Chemistry_Name": p["name"],
            "Initial_Capacity_MWh": capacity_mwh,
            "Cycles_Per_Day": cycles_per_day,
            "Average_DoD": avg_dod,
            "Cell_Temperature_C": avg_cell_temp_c,
            "HVAC_Parasitic_Loss_Percent": round(float(hvac_parasitic_ratio * 100.0), 2),
            "Years_Simulated": years,
            "EOL_Year_80_Percent": eol_year if eol_year else "> 15 lat",
            "SoH_After_10_Years_Percent": df_trajectory.loc[df_trajectory["Year"] == 10, "SoH_Percent"].iloc[0] if len(df_trajectory) >= 10 else None,
            "SoH_After_15_Years_Percent": df_trajectory.loc[df_trajectory["Year"] == 15, "SoH_Percent"].iloc[0] if len(df_trajectory) >= 15 else None,
            "Total_15Y_Throughput_GWh": round(float(cumulative_mwh_throughput / 1000.0), 2),
            "Estimated_LCOS_PLN_MWh": round(float(lcos_pln_mwh), 2),
            "CAPEX_Total_PLN": round(float(capex_total), 2),
            "Thermal_Runaway_Temp_C": p["thermal_runaway_temp_c"],
            "Trajectory_DataFrame": df_trajectory
        }

    @staticmethod
    def compare_lfp_vs_nmc(capacity_mwh: float = 6.0, cycles_per_day: float = 1.1) -> pd.DataFrame:
        """
        Generuje bezpośrednie zestawienie porównawcze LFP vs NMC dla decydentów UMK.
        """
        model_lfp = KrakowBessDegradationModel("LFP")
        model_nmc = KrakowBessDegradationModel("NMC")

        res_lfp = model_lfp.simulate_degradation_trajectory(capacity_mwh=capacity_mwh, cycles_per_day=cycles_per_day)
        res_nmc = model_nmc.simulate_degradation_trajectory(capacity_mwh=capacity_mwh, cycles_per_day=cycles_per_day)

        eol_lfp = f"{res_lfp['EOL_Year_80_Percent']} lat" if isinstance(res_lfp['EOL_Year_80_Percent'], (int, float)) else str(res_lfp['EOL_Year_80_Percent'])
        eol_nmc = f"{res_nmc['EOL_Year_80_Percent']} lat" if isinstance(res_nmc['EOL_Year_80_Percent'], (int, float)) else str(res_nmc['EOL_Year_80_Percent'])

        comp = [
            {"Kryterium": "Technologia", "LFP (Rekomendowane)": res_lfp["Chemistry_Name"], "NMC (Alternatywa)": res_nmc["Chemistry_Name"]},
            {"Kryterium": "Żywotność EOL (SoH <= 80%)", "LFP (Rekomendowane)": eol_lfp, "NMC (Alternatywa)": eol_nmc},
            {"Kryterium": "SoH po 10 latach", "LFP (Rekomendowane)": f"{res_lfp['SoH_After_10_Years_Percent']}%", "NMC (Alternatywa)": f"{res_nmc['SoH_After_10_Years_Percent']}%"},
            {"Kryterium": "SoH po 15 latach", "LFP (Rekomendowane)": f"{res_lfp['SoH_After_15_Years_Percent']}%", "NMC (Alternatywa)": f"{res_nmc['SoH_After_15_Years_Percent']}%"},
            {"Kryterium": "Przepustowość 15 lat (GWh)", "LFP (Rekomendowane)": f"{res_lfp['Total_15Y_Throughput_GWh']} GWh", "NMC (Alternatywa)": f"{res_nmc['Total_15Y_Throughput_GWh']} GWh"},
            {"Kryterium": "Koszt LCOS (PLN/MWh)", "LFP (Rekomendowane)": f"{res_lfp['Estimated_LCOS_PLN_MWh']} zł", "NMC (Alternatywa)": f"{res_nmc['Estimated_LCOS_PLN_MWh']} zł"},
            {"Kryterium": "CAPEX BESS (PLN)", "LFP (Rekomendowane)": f"{res_lfp['CAPEX_Total_PLN']:,.0f} zł", "NMC (Alternatywa)": f"{res_nmc['CAPEX_Total_PLN']:,.0f} zł"},
            {"Kryterium": "Pobór Własny HVAC Kontenera", "LFP (Rekomendowane)": f"~{res_lfp['HVAC_Parasitic_Loss_Percent']}% przepływu", "NMC (Alternatywa)": f"~{res_nmc['HVAC_Parasitic_Loss_Percent']}% przepływu"},
            {"Kryterium": "Temperatura Ucieczki Termicznej", "LFP (Rekomendowane)": f"{res_lfp['Thermal_Runaway_Temp_C']}°C (Bezpieczna)", "NMC (Alternatywa)": f"{res_nmc['Thermal_Runaway_Temp_C']}°C (Ryzyko pożaru)"}
        ]
        return pd.DataFrame(comp)
